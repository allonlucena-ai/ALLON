@file:Suppress("UnstableApiUsage")

import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.tasks.KotlinCompile
import java.io.FileInputStream
import java.util.Properties


plugins {
    id("com.android.application")
    kotlin("android")
    alias(libs.plugins.hilt)
    alias(libs.plugins.kotlin.ksp)
    alias(libs.plugins.compose.compiler)
    alias(libs.plugins.aboutlibraries)
}

val keystorePropertiesFile = rootProject.file("keystore.properties")
val keystoreProperties = Properties()
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(FileInputStream(keystorePropertiesFile))
}

/**
 * Credentials for the maintainer's services: the Last.fm API account and the polls' gist and Umami
 * site.
 *
 * In services.properties, which is committed. They used to live in the gitignored local.properties,
 * and that made a reproducible F-Droid build impossible: a build from source could never contain
 * what the published APK did. They only work in the app signed with the release key, see
 * BuiltInKeys.kt. local.properties is still read as a fallback, for a checkout whose
 * services.properties has not been filled in. Absent is a supported state: the build works, and
 * the features hide themselves rather than offering what cannot succeed.
 */
val servicesProperties = Properties()
rootProject.file("services.properties").takeIf { it.exists() }?.let { file ->
    FileInputStream(file).use { servicesProperties.load(it) }
}
val localPropertiesFile = rootProject.file("local.properties")
val localProperties = Properties()
if (localPropertiesFile.exists()) {
    localProperties.load(FileInputStream(localPropertiesFile))
}
fun service(key: String): String =
    servicesProperties.getProperty(key)?.takeIf { it.isNotBlank() } ?: localProperties.getProperty(key, "")

android {
    namespace = "com.dd3boh.outertune"
    compileSdk = 36

    defaultConfig {
        applicationId = "dev.skye.intertune"
        minSdk = 24
        targetSdk = 36
        versionCode = 103
        versionName = "0.12.11"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // Obfuscated, not encrypted, and the difference matters. Anything the app can read, so
        // can anyone holding the apk. What this does buy is that `strings app.apk | grep` no
        // longer finds the credentials lying in plain sight, which is how they are actually
        // harvested in bulk. Someone reading the code still gets them in a minute.
        //
        // The only real fix is a server relaying the calls, which this app does not have. A leaked
        // Last.fm key costs a rate limit, not an account, and is revocable, so this is the right
        // amount of effort for what is at stake. The values are in the public source now, for
        // reproducible builds, and what keeps them to this app is BuiltInKeys' signature check.
        fun obfuscated(value: String): String {
            // An empty int array, not an empty string. These fields are declared int[], so
            // returning "\"\"" emitted `public static final int[] X = "";` and the whole app
            // stopped compiling the moment local.properties was absent, which is every build
            // from source: a fresh clone, a contributor, and F-Droid's buildserver. Both
            // reveal() functions already turn an empty array back into an empty string, so the
            // features switch themselves off exactly as their comments promise.
            if (value.isEmpty()) return "new int[]{}"
            val mask = "InterTune".toByteArray()
            val out = value.toByteArray().mapIndexed { i, b ->
                (b.toInt() xor mask[i % mask.size].toInt()) and 0xff
            }
            return out.joinToString(prefix = "new int[]{", postfix = "}")
        }
        buildConfigField(
            "int[]",
            "LASTFM_API_KEY",
            obfuscated(service("lastfm.apiKey"))
        )
        buildConfigField(
            "int[]",
            "LASTFM_API_SECRET",
            obfuscated(service("lastfm.apiSecret"))
        )

        // Polls, same treatment and the same honesty about it. None of these is a secret, but the
        // Umami website id lets anyone post events to that site, and the gist url is a maintainer
        // address that does not need to be handed out in a grep.
        buildConfigField(
            "int[]",
            "POLLS_URL",
            obfuscated(service("polls.gistUrl"))
        )
        buildConfigField(
            "int[]",
            "POLLS_UMAMI_URL",
            obfuscated(service("polls.umamiUrl"))
        )
        buildConfigField(
            "int[]",
            "POLLS_UMAMI_WEBSITE_ID",
            obfuscated(service("polls.umamiWebsiteId"))
        )
    }

    signingConfigs {
        if (!keystoreProperties.isEmpty) {
            create("ot_release") {
                storeFile = file(keystoreProperties["storeFile"] as String)
                (keystoreProperties["keyAlias"] as? String)?.let {
                    keyAlias = it
                }
                (keystoreProperties["keyPassword"] as? String)?.let {
                    keyPassword = it
                }
                (keystoreProperties["storePassword"] as? String)?.let {
                    storePassword = it
                }
            }
        }
        // No else branch. It used to create an empty ot_release here, which the release build
        // type then pointed at, and AGP stops at packaging with "missing required property
        // storeFile" because a signing config with no keystore in it is not a signing config.
        // Leaving the name undefined lets findByName below return null, which is how you ask
        // AGP for an unsigned apk, and unsigned is exactly what a build from source should
        // produce: F-Droid signs its own, and so does anyone else building this without a key.
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            isCrunchPngs = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("ot_release")
            // The app's own screens in a car (AutoCarService, AutoSettingsService) exist only where
            // Unreleased.AUTO_REWORK is on: a car that finds them draws the app from them, held back or not.
            manifestPlaceholders["carScreens"] = "false"
            // The widget's settings: a dialog. Where Unreleased.WIDGET_ON_WALLPAPER is on (every debuggable
            // build), a full window over the wallpaper; a dialog there lets the home screen show through.
            manifestPlaceholders["widgetConfigTheme"] = "@style/Theme.InterTune.WidgetConfig"
        }
        debug {
            applicationIdSuffix = ".debug"
            manifestPlaceholders["carScreens"] = "true"
            manifestPlaceholders["widgetConfigTheme"] = "@style/Theme.InterTune.WidgetConfig.Wallpaper"
        }

        // A debug build that installs beside the release and the debug build, for trying a
        // release candidate on a fresh profile without touching the debug install that holds a
        // real library. Its name and shortcuts are in src/preview.
        create("preview") {
            initWith(getByName("debug"))
            applicationIdSuffix = ".preview"
            matchingFallbacks += listOf("debug")
            // A preview published for testers carries its own version, so Obtainium can tell one
            // build from the next: tools/preview/publish-preview.sh passes -PpreviewVersion=<stamp>.
            // Without the property nothing changes.
            (project.findProperty("previewVersion") as String?)?.let { versionNameSuffix = "-preview.$it" }
        }

        // userdebug is release builds without minify
        create("userdebug") {
            initWith(getByName("release"))
            isMinifyEnabled = false
            isShrinkResources = false
//            isDebuggable = true
            isProfileable = true
            matchingFallbacks += listOf("release")
        }
    }

    // userdebug is release without minify: to a car it says what release says (src/release).
    sourceSets {
        getByName("userdebug") {
            manifest.srcFile("src/release/AndroidManifest.xml")
            res.srcDir("src/release/res")
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

// build variants and stuff
//    splits {
//        abi {
//            isEnable = true
//            reset()
//
//            include("x86_64", "x86", "armeabi-v7a", "arm64-v8a")
//            isUniversalApk = true
//        }
//    }

    flavorDimensions.add("abi")

    productFlavors {
        // main version
        create("core") {
            isDefault = true
            dimension = "abi"
        }

        // fully featured version, large file size
        create("full") {
            dimension = "abi"
        }
    }

    applicationVariants.all {
        val variant = this
        variant.outputs
            .map { it as com.android.build.gradle.internal.api.BaseVariantOutputImpl }
            .forEach { output ->
                var outputFileName = "InterTune-${variant.versionName}-${output.baseName}-${output.versionCode}.apk"
                output.outputFileName = outputFileName
            }
    }

    compileOptions {
        isCoreLibraryDesugaringEnabled = true
        sourceCompatibility = JavaVersion.VERSION_21
        targetCompatibility = JavaVersion.VERSION_21
    }
    kotlin {
        jvmToolchain(21)
        compilerOptions {
            jvmTarget.set(JvmTarget.JVM_21)
            freeCompilerArgs.add("-Xannotation-default-target=param-property")

        }
    }

    tasks.withType<KotlinCompile> {
        if (!name.substringAfter("compile").lowercase().startsWith("full")) {
            exclude("**/*FFmpegScanner.kt")
            exclude("**/*NextRendersFactory.kt")
        } else {
            exclude("**/*FFmpegScannerDud.kt")
            exclude("**/*ffdecoderDud.kt")
        }
    }


    aboutLibraries {
        offlineMode = true

        collect {
            fetchRemoteLicense = false
            fetchRemoteFunding = false
            filterVariants.addAll("release")
            // Libraries built from source rather than taken from Maven, which the plugin cannot see:
            // InnerTubeX's SABR client, compiled into the :sabr module.
            configPath = file("../config")
        }

        export {
            // Remove the "generated" timestamp to allow for reproducible builds
            excludeFields = listOf("generated")
        }

        license {
            // Define the strict mode, will fail if the project uses licenses not allowed
            strictMode = com.mikepenz.aboutlibraries.plugin.StrictMode.FAIL
            // Allowed set of licenses, this project will be able to use without build failure
            allowedLicenses.addAll("Apache-2.0", "BSD-3-Clause", "GNU LESSER GENERAL PUBLIC LICENSE, Version 2.1", "GNU GENERAL PUBLIC LICENSE, Version 3", "GPL-3.0-only", "GPL-3.0-or-later", "EPL-2.0", "MIT", "MPL-2.0", "Public Domain")

            // Full license text for license IDs mentioned here will be included, even if no detected dependency uses them.
             additionalLicenses.addAll("apache_2_0", "gpl_2_1") // taglib, ffMpeg in ffMetadataEx
        }

        library {
            duplicationMode = com.mikepenz.aboutlibraries.plugin.DuplicateMode.MERGE
            duplicationRule = com.mikepenz.aboutlibraries.plugin.DuplicateRule.SIMPLE
        }
    }

    // for RB
    dependenciesInfo {
        // Disables dependency metadata when building APKs.
        includeInApk = false
        // Disables dependency metadata when building Android App Bundles.
        includeInBundle = false
    }

    testOptions {
        unitTests.isIncludeAndroidResources = true
        unitTests.isReturnDefaultValues = true
    }

    lint {
        lintConfig = file("lint.xml")
    }

    androidResources {
        generateLocaleConfig = true
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation(libs.kyant.backdrop)
    implementation(libs.guava)
    implementation(libs.coroutines.guava)
    implementation(libs.concurrent.futures)

    implementation(libs.activity)
    implementation(libs.hilt.navigation)
    implementation(libs.datastore)

    // compose
    implementation(libs.compose.runtime)
    implementation(libs.compose.foundation)
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.util)
    // Debug only: it brings PreviewActivity with it, exported, and a release has no use for it.
    debugImplementation(libs.compose.ui.tooling)
    implementation(libs.compose.animation)
    implementation(libs.compose.reorderable)
    implementation(libs.compose.icons.extended)

    // ui
    implementation(libs.coil)
    implementation(libs.coil.network.okhttp)
    implementation(libs.shimmer)
    implementation(libs.glance)
    implementation(libs.glance.material3)

    // material
    implementation(libs.adaptive)
    implementation(libs.material3)
    implementation(libs.palette)

    // viewmodel
    implementation(libs.viewmodel)
    implementation(libs.viewmodel.compose)

    implementation(libs.media3)
    implementation(libs.media3.okhttp)
    implementation(libs.media3.session)
    implementation(libs.media3.workmanager)
    // Lyrics shared as a video: the clip's frames and the song's audio encoded on the phone (LyricsVideo).
    implementation(libs.media3.transformer)
    implementation(libs.media3.effect)
    // The app's own screens in a car: a car draws them from this and nothing else. The second is what
    // the first hands the session to the car with; it comes with it either way, named here to compile against.
    implementation(libs.car.app)
    implementation(libs.media.compat)

    implementation(libs.room.runtime)
    ksp(libs.room.compiler)
    implementation(libs.room.ktx)

    implementation(libs.apache.lang3)

    implementation(libs.hilt)
    ksp(libs.hilt.compiler)

    coreLibraryDesugaring(libs.desugaring)

    implementation(libs.ktor.client.core)
    implementation(libs.ktor.serialization.json)

    // Runs the recommendation SQL against the real exported Room schema on the JVM, with no
    // emulator. See RecommendationSqlTest.
    testImplementation(libs.junit)
    testImplementation(libs.sqlite.jdbc)
    // The XML pull parser Android itself uses, so the lyrics TTML parser runs in plain JVM tests,
    // where android.util.Xml has no parser behind it. See TtmlInternalNamespaceTest.
    testImplementation(libs.kxml2)
    // YouTube's answers turned into the exceptions the app's client throws, with no network. See
    // WhyStoppedTest.
    testImplementation(libs.ktor.client.mock)

    // modules
    implementation(project(":fingerprint"))
    implementation(project(":innertube"))
    implementation(project(":sabr"))
    implementation(libs.ktor.client.okhttp)
    implementation(project(":kugou"))
    implementation(project(":lrclib"))
    implementation(project(":lastfm"))
    implementation(libs.work)

    testImplementation(libs.junit)
    implementation(project(":material-color-utilities"))
    implementation(project(":taglib"))

    // misc
    implementation(libs.aboutlibraries.compose.m3)

    // sdk24 support
    // Support for N is officially unsupported even it the app should still work. Leave this outside of the version catalog.
    implementation("androidx.webkit:webkit:1.14.0")
}

afterEvaluate {
    dependencies {
        add("fullImplementation", project(":ffMetadataEx"))
    }
}

// Hilt's generated Java is compiled by its own task, which takes the JDK that runs Gradle rather
// than the toolchain above, so a machine whose Gradle runs on 17 failed on "invalid source
// release: 21". Every Java compile here uses the same JDK 21 as the Kotlin, as F-Droid's server does.
tasks.withType<JavaCompile>().configureEach {
    javaCompiler.set(javaToolchains.compilerFor { languageVersion.set(JavaLanguageVersion.of(21)) })
}
