/*
 * Copyright (C) 2026 InterTune
 *
 * SPDX-License-Identifier: GPL-3.0
 */

package com.dd3boh.outertune.ui.player

import com.dd3boh.outertune.playback.MusicLevels
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.exp

/**
 * The living background: the cover as a few patches of colour that breathe with the music. Still,
 * it has to look like the cover it came from; moving, it has to follow the kick and then calm
 * down, and stop altogether when the music does.
 */
class LivingFieldTest {

    private val red = 0xffcc2211.toInt()
    private val green = 0xff11aa33.toInt()
    private val blue = 0xff2233dd.toInt()
    private val dark = 0xff0a0a0c.toInt()

    /** A square cover of four plain quarters: red and green above, blue and dark below. */
    private fun quarters(side: Int) = IntArray(side * side) {
        val x = it % side
        val y = it / side
        when {
            y < side / 2 && x < side / 2 -> red
            y < side / 2 -> green
            x < side / 2 -> blue
            else -> dark
        }
    }

    private val g = 4

    /** What a patch shows for a part of the cover that is all [color]. */
    private fun patchOf(color: Int) = LivingField.colourful(color, LivingField.COLOUR)

    @Test
    fun `each patch is the colour of its part of the cover`() {
        val patches = LivingField.patches(quarters(100), 100, 100, g, g)
        assertEquals(g * g, patches.size)
        for (row in 0 until g) for (column in 0 until g) {
            val want = when {
                row < g / 2 && column < g / 2 -> red
                row < g / 2 -> green
                column < g / 2 -> blue
                else -> dark
            }
            assertEquals("row $row, column $column", patchOf(want), patches[row * g + column])
        }
    }

    @Test
    fun `the grid need not be square`() {
        // three across and six down, as on a phone held upright: the top half red and green, the bottom half blue and dark
        val patches = LivingField.patches(quarters(120), 120, 120, 3, 6)
        assertEquals(18, patches.size)
        assertEquals(patchOf(red), patches[0])
        assertEquals(patchOf(green), patches[2])
        assertEquals(patchOf(blue), patches[5 * 3])
        assertEquals(patchOf(dark), patches[5 * 3 + 2])
        // the middle column lies across the line between two quarters
        assertTrue(patches[1] != patchOf(red) && patches[1] != patchOf(green))
    }

    @Test
    fun `patches are about as wide as they are tall`() {
        assertEquals("a phone upright, 448 by 997 dp", 7, LivingField.along(997f, 448f))
        assertEquals("a short phone", 5, LivingField.along(640f, 360f))
        assertEquals("a square window", 3, LivingField.along(600f, 600f))
        assertEquals("a tablet on its side", 5, LivingField.along(1280f, 800f))
        assertEquals("never more than seven", 7, LivingField.along(3000f, 300f))
        assertEquals("nothing measured yet", 3, LivingField.along(0f, 0f))
    }

    @Test
    fun `more colourful, and a grey stays the grey it is`() {
        assertEquals(0xff808080.toInt(), LivingField.colourful(0xff808080.toInt(), 1.3f))
        assertEquals(0xff000000.toInt(), LivingField.colourful(0xff000000.toInt(), 1.3f))
        assertEquals(0xffffffff.toInt(), LivingField.colourful(0xffffffff.toInt(), 1.3f))
        val brown = 0xff8a5a3c.toInt()
        val more = LivingField.colourful(brown, 1.3f)
        assertTrue("red further up: ${Integer.toHexString(more)}", (more shr 16 and 0xff) > 0x8a)
        assertTrue("blue further down", (more and 0xff) < 0x3c)
        assertEquals("unchanged at 1", brown, LivingField.colourful(brown, 1f))
        assertEquals("nothing leaves the range", 0xffff0000.toInt(), LivingField.colourful(0xffff0000.toInt(), 3f))
    }

    @Test
    fun `a patch across two colours is their mix`() {
        // 8 pixels wide, so 2 to a column: black up to the third pixel, white from the fourth
        val stripes = IntArray(8 * 8) { if (it % 8 < 3) 0xff000000.toInt() else 0xffffffff.toInt() }
        val patches = LivingField.patches(stripes, 8, 8, g, g)
        assertEquals(0xff000000.toInt(), patches[0])
        assertEquals("the second column holds one black pixel and one white", 0xff7f7f7f.toInt(), patches[1])
        assertEquals(0xffffffff.toInt(), patches[2])
    }

    @Test
    fun `a cover smaller than the grid or missing still gives every patch a colour`() {
        val tiny = LivingField.patches(intArrayOf(red, green, blue, dark), 2, 2, g, g)
        assertEquals(patchOf(red), tiny[0])
        assertEquals(patchOf(dark), tiny[g * g - 1])
        assertTrue(LivingField.patches(IntArray(0), 0, 0, g, g).all { it == LivingField.GREY })
        assertTrue("fewer pixels than it says", LivingField.patches(IntArray(10), 100, 100, g, g).all { it == LivingField.GREY })
    }

    @Test
    fun `the glow takes the cover's strongest colour`() {
        val patches = LivingField.patches(quarters(100), 100, 100, g, g)
        val strongest = LivingField.strongest(patches)
        assertTrue("one of the colours, not the dark quarter", strongest in listOf(red, blue, green).map(::patchOf))
        // a dark cover with one lit corner: the lit corner
        val moody = IntArray(16) { dark }.also { it[5] = 0xff803010.toInt() }
        assertEquals(0xff803010.toInt(), LivingField.strongest(moody))
        // no colour at all: the lightest grey
        val greys = IntArray(16) { 0xff202020.toInt() }.also { it[9] = 0xffb0b0b0.toInt() }
        assertEquals(0xffb0b0b0.toInt(), LivingField.strongest(greys))
    }

    @Test
    fun `light is turned up and down without a channel running over`() {
        assertEquals(0xff804020.toInt(), LivingField.lit(0xff804020.toInt(), 1f))
        assertEquals(0xff402010.toInt(), LivingField.lit(0xff804020.toInt(), 0.5f))
        assertEquals(0xffff8040.toInt(), LivingField.lit(0xff804020.toInt(), 2f))
        assertEquals("red is full, the others still rise", 0xffffc060.toInt(), LivingField.lit(0xff804020.toInt(), 3f))
        assertEquals(0xff000000.toInt(), LivingField.lit(0xff804020.toInt(), 0f))
    }

    @Test
    fun `one colour turns into another channel by channel`() {
        assertEquals(red, LivingField.between(red, blue, 0f))
        assertEquals(blue, LivingField.between(red, blue, 1f))
        assertEquals(0xff808080.toInt(), LivingField.between(0xff000000.toInt(), 0xffffffff.toInt(), 0.5f))
        assertEquals(blue, LivingField.between(red, blue, 7f))
    }

    @Test
    fun `the top and the bottom of the screen follow the bass, the middle the voice and the top of the spectrum`() {
        fun bands(rows: Int) = (0 until rows).map { LivingField.bandOfRow(it, rows) }
        val (b, m, h) = Triple(MusicLevels.BASS, MusicLevels.MID, MusicLevels.HIGH)
        assertEquals("a phone upright", listOf(b, b, m, h, m, b, b), bands(7))
        assertEquals(listOf(b, m, h, h, m, b), bands(6))
        assertEquals(listOf(b, m, h, m, b), bands(5))
        assertEquals(listOf(b, m, m, b), bands(4))
        assertEquals("the strip in Settings, and a phone on its side", listOf(b, m, b), bands(3))
        assertEquals(listOf(b, b), bands(2))
        assertEquals(listOf(b), bands(1))
    }

    // The cover's main colours, as the other way of colouring it

    private fun near(a: Int, b: Int, within: Int = 40): Boolean =
        abs((a shr 16 and 0xff) - (b shr 16 and 0xff)) <= within &&
            abs((a shr 8 and 0xff) - (b shr 8 and 0xff)) <= within &&
            abs((a and 0xff) - (b and 0xff)) <= within

    /** Where on the colour wheel a colour is, in degrees. */
    private fun hue(color: Int): Float {
        val r = color shr 16 and 0xff
        val g = color shr 8 and 0xff
        val b = color and 0xff
        val most = maxOf(r, g, b)
        val chroma = most - minOf(r, g, b)
        if (chroma == 0) return Float.NaN
        val sixth = when (most) {
            r -> ((g - b).toFloat() / chroma).let { if (it < 0) it + 6 else it }
            g -> (b - r).toFloat() / chroma + 2
            else -> (r - g).toFloat() / chroma + 4
        }
        return sixth * 60
    }

    private fun apart(a: Int, b: Int): Float = abs(hue(a) - hue(b)).let { minOf(it, 360 - it) }

    private fun isGrey(color: Int) = abs((color shr 16 and 0xff) - (color shr 8 and 0xff)) < 8 && abs((color shr 8 and 0xff) - (color and 0xff)) < 8

    /** A cover of plain parts: [parts] of [colors], left to right, by how many columns of 100 each takes. */
    private fun stripes(vararg parts: Pair<Int, Int>): IntArray {
        val row = parts.flatMap { (color, columns) -> List(columns) { color } }
        check(row.size == 100) { "the parts make ${row.size} columns" }
        return IntArray(100 * 100) { row[it % 100] }
    }

    @Test
    fun `the main colours are the cover's hues, the heaviest for the bass and the lighter of the rest for the top`() {
        val mains = LivingField.mainColours(quarters(100), 100, 100)
        assertEquals(3, mains.size)
        // a quarter each, and the blue is the most colourful of the three
        assertTrue("the bass ${Integer.toHexString(mains[0])} is the blue", apart(mains[MusicLevels.BASS], blue) < 12)
        assertTrue("the voice ${Integer.toHexString(mains[1])} is the red, the darker of the other two", apart(mains[MusicLevels.MID], red) < 12)
        assertTrue("the top ${Integer.toHexString(mains[2])} is the green", apart(mains[MusicLevels.HIGH], green) < 12)
        assertFalse("the dark quarter is not a main colour", mains.any { near(it, dark, 20) })
    }

    @Test
    fun `two shades of one hue are one colour, however unlike they are channel for channel`() {
        // Magenta, pink and green, as on the cover this was got wrong for: it took the magenta
        // and the pink for two colours and gave the green the row behind the cover.
        val magenta = 0xffd01fb8.toInt()
        val pink = 0xffff7fe0.toInt()
        val leaf = 0xff3fd43a.toInt()
        val mains = LivingField.mainColours(stripes(magenta to 40, pink to 35, leaf to 25), 100, 100)
        assertTrue("the bass ${Integer.toHexString(mains[0])} is the magenta and the pink together", apart(mains[MusicLevels.BASS], magenta) < 20)
        val others = listOf(mains[MusicLevels.MID], mains[MusicLevels.HIGH])
        assertTrue("one of the others is the green: ${others.map(Integer::toHexString)}", others.any { apart(it, leaf) < 15 })
        assertFalse("and neither is the pink: ${others.map(Integer::toHexString)}", others.any { near(it, pink, 40) || near(it, magenta, 40) })
        for (i in 0 until 3) for (j in i + 1 until 3) {
            assertFalse("${Integer.toHexString(mains[i])} and ${Integer.toHexString(mains[j])} are told apart", near(mains[i], mains[j], 40))
        }
    }

    @Test
    fun `of the cover's colours the two furthest from the bass's and from each other are taken`() {
        // Magenta, a rose close to it, green and white, by how much of the cover each has. The
        // rose is the second most of it, and is the one left out: it is the magenta's neighbour.
        val magenta = 0xffd01fb8.toInt()
        val rose = 0xffe64b78.toInt()
        val leaf = 0xff3fd43a.toInt()
        val white = 0xfff2f2f2.toInt()
        val mains = LivingField.mainColours(stripes(magenta to 40, rose to 25, leaf to 20, white to 15), 100, 100)
        assertTrue("the bass ${Integer.toHexString(mains[0])}", apart(mains[MusicLevels.BASS], magenta) < 20)
        assertTrue("the voice ${Integer.toHexString(mains[1])} is the green", apart(mains[MusicLevels.MID], leaf) < 15)
        assertTrue("the top ${Integer.toHexString(mains[2])} is the white", isGrey(mains[MusicLevels.HIGH]) && LivingField.luma(mains[MusicLevels.HIGH]) > 200)
    }

    @Test
    fun `a speck of another colour is not a main colour`() {
        val mains = LivingField.mainColours(stripes(blue to 99, red to 1), 100, 100)
        assertTrue(apart(mains[MusicLevels.BASS], blue) < 12)
        assertFalse("the red speck is none of them: ${mains.map(Integer::toHexString)}", mains.any { apart(it, red) < 20 })
    }

    @Test
    fun `the cover's white is one of its colours, and the lightest goes to the top of the spectrum`() {
        val white = 0xfff4f4f0.toInt()
        val mains = LivingField.mainColours(stripes(red to 50, green to 30, white to 20), 100, 100)
        assertTrue(apart(mains[MusicLevels.BASS], red) < 12)
        assertTrue(apart(mains[MusicLevels.MID], green) < 12)
        assertTrue("the top ${Integer.toHexString(mains[2])} is the white, a little short of full", isGrey(mains[MusicLevels.HIGH]) && LivingField.luma(mains[MusicLevels.HIGH]) in 200..235)
    }

    @Test
    fun `a cover of one colour gives that colour and two neighbours of it`() {
        val plain = IntArray(64 * 64) { red }
        val mains = LivingField.mainColours(plain, 64, 64)
        assertTrue(apart(mains[MusicLevels.BASS], red) < 8)
        assertEquals("three different ones, or the screen would be one flat colour", 3, mains.toSet().size)
        assertTrue("the voice is a little way round the wheel: ${apart(mains[MusicLevels.MID], red)}", apart(mains[MusicLevels.MID], red) in 25f..50f)
        assertTrue("the top is lighter than both", LivingField.luma(mains[MusicLevels.HIGH]) > LivingField.luma(mains[MusicLevels.BASS]) + 40)
        // still the red's family: redder than they are green or blue, all three
        for (main in mains) assertTrue(Integer.toHexString(main), (main shr 16 and 0xff) > (main shr 8 and 0xff) && (main shr 16 and 0xff) > (main and 0xff))
    }

    @Test
    fun `a dark colour is given enough light to be seen moving`() {
        val navy = 0xff0c1440.toInt()
        val mains = LivingField.mainColours(IntArray(64 * 64) { navy }, 64, 64)
        val bass = mains[MusicLevels.BASS]
        assertTrue("still a blue: ${Integer.toHexString(bass)}", apart(bass, navy) < 12)
        assertTrue("and no longer nearly black: ${Integer.toHexString(bass)}", (bass and 0xff) >= 110)
        assertTrue("nor more of a blue than the navy is, by much", LivingField.colourfulness(bass) <= LivingField.colourfulness(navy) * 1.75f)
    }

    @Test
    fun `a grey cover with an accent keeps its grey for the bass and the accent for one of the others`() {
        val black = 0xff050505.toInt()
        val mains = LivingField.mainColours(stripes(black to 92, red to 8), 100, 100)
        assertTrue("the bass ${Integer.toHexString(mains[0])} is a grey, darker than the stand-in one", isGrey(mains[MusicLevels.BASS]) && LivingField.luma(mains[MusicLevels.BASS]) in 80..120)
        assertTrue("the red is there: ${mains.map(Integer::toHexString)}", listOf(mains[MusicLevels.MID], mains[MusicLevels.HIGH]).any { !isGrey(it) && apart(it, red) < 12 })
        assertEquals(3, mains.toSet().size)
    }

    @Test
    fun `a grey cover gives greys that can be told apart, and no cover gives the stand-in grey`() {
        val greys = IntArray(64 * 64) { if (it % 64 < 32) 0xff303030.toInt() else 0xffa0a0a0.toInt() }
        val mains = LivingField.mainColours(greys, 64, 64)
        for (main in mains) assertTrue(Integer.toHexString(main), isGrey(main))
        val lights = mains.map(LivingField::luma).sorted()
        assertTrue("three greys a step apart: $lights", lights[1] - lights[0] >= 20 && lights[2] - lights[1] >= 20)
        val whiteOnBlack = IntArray(64 * 64) { if (it % 64 < 50) 0xff000000.toInt() else 0xffffffff.toInt() }
        val drawn = LivingField.mainColours(whiteOnBlack, 64, 64)
        assertEquals("black, white and something between: ${drawn.map(Integer::toHexString)}", 3, drawn.toSet().size)
        assertTrue(drawn.all(::isGrey))
        assertTrue(LivingField.mainColours(IntArray(0), 0, 0).all { it == LivingField.GREY })
    }

    private fun rgb(r: Int, g: Int, b: Int) = (0xff shl 24) or (r shl 16) or (g shl 8) or b

    @Test
    fun `a black that leans a hair towards blue is black, and its cover has no blue`() {
        // AC/DC's Back in Black, as the app read it on 7 Oct 2026: a black cover with grey
        // lettering, and the voice's rows came out royal blue. A black of 6, 6, 20 measures as
        // colourful as a visible slate does, and what was taken for the cover's accent was then
        // lifted into the light, tint and all.
        val black = rgb(0, 0, 0)
        val lettering = rgb(95, 100, 98)
        for ((what, nearly) in listOf("6, 6, 20" to rgb(6, 6, 20), "2, 2, 8" to rgb(2, 2, 8), "12, 12, 26" to rgb(12, 12, 26))) {
            val mains = LivingField.mainColours(stripes(black to 80, nearly to 17, lettering to 3), 100, 100)
            for (main in mains) assertTrue("a black of $what gave ${mains.map(Integer::toHexString)}", isGrey(main))
        }
        val all = LivingField.mainColours(IntArray(64 * 64) { rgb(6, 6, 20) }, 64, 64)
        assertTrue("a cover of nothing else: ${all.map(Integer::toHexString)}", all.all(::isGrey))
    }

    @Test
    fun `a black cover gives black, grey and white, far enough apart to be seen`() {
        val mains = LivingField.mainColours(stripes(rgb(16, 17, 21) to 97, rgb(95, 100, 98) to 3), 100, 100)
        val (bass, voice, top) = mains.map(LivingField::luma)
        assertTrue("${mains.map(Integer::toHexString)}", mains.all(::isGrey))
        assertTrue("the bass keeps the cover's black, lit enough to be seen moving: $bass", bass in 80..110)
        assertTrue("the voice a clear step up: $voice", voice >= bass + 35)
        assertTrue("and the top is its white: $top", top >= 200 && top >= voice + 35)
    }

    @Test
    fun `a dark colour that really is one still counts, and a few stray pixels do not`() {
        val navy = rgb(12, 20, 64)
        val dark = LivingField.mainColours(stripes(rgb(0, 0, 0) to 60, navy to 40), 100, 100)
        assertTrue("a navy is a blue: ${dark.map(Integer::toHexString)}", dark.any { !isGrey(it) && apart(it, navy) < 15 })
        // half a hundredth of the cover in a vivid red: not its accent
        val stray = IntArray(100 * 100) { if (it % 200 == 0) red else rgb(10, 10, 10) }
        val mains = LivingField.mainColours(stray, 100, 100)
        assertTrue("${mains.map(Integer::toHexString)}", mains.all(::isGrey))
    }

    @Test
    fun `a main colour is not much more colourful than it is on the cover`() {
        // a slate with a faint blue cast: lifted into the light as it stood, it came out a steel blue
        val slate = rgb(40, 48, 60)
        val bass = LivingField.mainColours(IntArray(64 * 64) { slate }, 64, 64)[MusicLevels.BASS]
        assertTrue("lighter than the slate: ${Integer.toHexString(bass)}", LivingField.luma(bass) > LivingField.luma(slate) + 40)
        assertTrue("and no more than a little more colourful: ${LivingField.colourfulness(bass)} against ${LivingField.colourfulness(slate)}",
            LivingField.colourfulness(bass) <= LivingField.colourfulness(slate) * 1.75f)
        // a colour that is light already is left as colourful as it is
        val leaf = rgb(63, 212, 58)
        val kept = LivingField.mainColours(IntArray(64 * 64) { leaf }, 64, 64)[MusicLevels.BASS]
        assertTrue(LivingField.colourfulness(kept) >= LivingField.colourfulness(leaf) * 0.95f)
        assertEquals("a grey measures as no colour", 0f, LivingField.colourfulness(rgb(128, 128, 128)), 0.002f)
        assertTrue("and a pure red as a lot", LivingField.colourfulness(rgb(255, 0, 0)) in 0.24f..0.28f)
    }

    @Test
    fun `whatever the cover, there are three colours, no two the same and none see-through`() {
        fun check(what: String, pixels: IntArray, width: Int, height: Int) {
            val mains = LivingField.mainColours(pixels, width, height)
            assertEquals(what, 3, mains.size)
            assertEquals("$what: ${mains.map(Integer::toHexString)}", 3, mains.toSet().size)
            assertTrue(what, mains.all { it ushr 24 == 0xff })
        }
        check("all black", IntArray(32 * 32) { 0xff000000.toInt() }, 32, 32)
        check("all white", IntArray(32 * 32) { 0xffffffff.toInt() }, 32, 32)
        check("one pixel", intArrayOf(red), 1, 1)
        check("see-through pixels count by their colour", IntArray(32 * 32) { 0x00cc2211 }, 32, 32)
        check("a very large one is not read pixel by pixel", IntArray(1500 * 1500) { if (it % 3 == 0) red else blue }, 1500, 1500)
        val random = java.util.Random(7)
        repeat(300) { n ->
            // a few plain colours in blocks, some covers nearly grey, some of one hue
            val side = 8 + random.nextInt(24)
            val colours = IntArray(1 + random.nextInt(5)) {
                when (n % 3) {
                    0 -> random.nextInt(0x1000000)
                    1 -> (random.nextInt(256)).let { v -> (v shl 16) or ((v + random.nextInt(9) - 4).coerceIn(0, 255) shl 8) or v }
                    else -> (random.nextInt(256) shl 16) or (random.nextInt(40) shl 8) or random.nextInt(40)
                } or (0xff shl 24)
            }
            check("cover $n", IntArray(side * side) { colours[(it / side * colours.size / side + it % 3) % colours.size] }, side, side)
        }
    }

    @Test
    fun `a hue is turned round the wheel and stays as light and as colourful`() {
        assertTrue("red a third of the way round is green", apart(LivingField.turned(0xffcc2020.toInt(), 120f), 0xff20cc20.toInt()) < 2)
        assertEquals(0xff20cc20.toInt(), LivingField.turned(0xffcc2020.toInt(), 120f))
        assertEquals("and all the way round is itself", 0xffcc2020.toInt(), LivingField.turned(0xffcc2020.toInt(), 360f))
        assertEquals("backwards too", 0xff2020cc.toInt(), LivingField.turned(0xffcc2020.toInt(), -120f))
        assertEquals("a grey has no hue to turn", 0xff808080.toInt(), LivingField.turned(0xff808080.toInt(), 90f))
    }

    // With a colour to each range the ranges lie in ribbons with curved edges, not in rows

    private val shares = FloatArray(3)
    private fun sharesAt(x: Float, y: Float, time: Float = 0f, bass: Float = 0f, voice: Float = 0f, top: Float = 0f): List<Float> {
        LivingField.flowShares(x, y, time, bass, voice, top, shares)
        return shares.toList()
    }

    @Test
    fun `the top and the bottom of the picture are the bass's, the middle line the top's, and the voice lies between`() {
        for (time in listOf(0f, 3.7f, 11f, 42f)) for (x in listOf(0.05f, 0.3f, 0.5f, 0.77f, 0.95f)) {
            assertEquals("the top edge at $x, $time", listOf(1f, 0f, 0f), sharesAt(x, 0.02f, time))
            assertEquals("the bottom edge at $x, $time", listOf(1f, 0f, 0f), sharesAt(x, 0.98f, time))
            val line = LivingField.flowLine(x, time)
            assertTrue("the line stays about the middle: $line", line in 0.42f..0.64f)
            assertEquals("on the line at $x, $time", listOf(0f, 0f, 1f), sharesAt(x, line, time))
            for (above in listOf(true, false)) {
                val half = (LivingField.flowTop(x, time, 0f) + LivingField.flowReach(x, time, above, 0f, 0f, 0f)) / 2
                assertEquals("half way to the bass at $x, $time", listOf(0f, 1f, 0f), sharesAt(x, if (above) line - half else line + half, time))
            }
        }
    }

    @Test
    fun `wherever and whenever, and whatever the music does, a place is shared out whole`() {
        val random = java.util.Random(3)
        repeat(4000) {
            val got = sharesAt(random.nextFloat(), random.nextFloat(), random.nextFloat() * 500, random.nextFloat() * 3, random.nextFloat() * 3, random.nextFloat() * 3)
            assertTrue("$got", got.all { it in 0f..1f })
            assertEquals("$got", 1f, got.sum(), 0.001f)
        }
    }

    @Test
    fun `no edge is a straight line, and the two sides are not each other's mirror`() {
        val across = (0..20).map { it / 20f }
        for (time in listOf(0f, 9f, 31f)) {
            val line = across.map { LivingField.flowLine(it, time) }
            assertTrue("the top's line rises and falls across the picture: ${line.max() - line.min()}", line.max() - line.min() > 0.05f)
            val upper = across.map { LivingField.flowLine(it, time) - LivingField.flowVoice(it, time, true, 0f, 0f) }
            val lower = across.map { LivingField.flowLine(it, time) + LivingField.flowVoice(it, time, false, 0f, 0f) }
            assertTrue("the bass's edge above it curves: ${upper.max() - upper.min()}", upper.max() - upper.min() > 0.05f)
            assertTrue("and the one below", lower.max() - lower.min() > 0.05f)
            val unlike = across.maxOf { abs(LivingField.flowVoice(it, time, true, 0f, 0f) - LivingField.flowVoice(it, time, false, 0f, 0f)) }
            assertTrue("the voice reaches further on one side than the other somewhere: $unlike", unlike > 0.04f)
        }
        // so one height is one range at the left of the picture and another at the right
        val heights = (0..100).map { it / 100f }
        assertTrue(heights.any { y -> sharesAt(0.1f, y).indexOfFirst { it > 0.9f }.let { left -> left >= 0 && sharesAt(0.9f, y).indexOfFirst { it > 0.9f }.let { right -> right >= 0 && right != left } } })
    }

    @Test
    fun `the ribbons flow with the picture's time`() {
        val places = (1..9).flatMap { x -> (1..19).map { y -> x / 10f to y / 20f } }
        val moved = places.maxOf { (x, y) -> sharesAt(x, y, 0f).zip(sharesAt(x, y, 6f)).maxOf { (a, b) -> abs(a - b) } }
        assertTrue("six seconds on, somewhere has changed hands: $moved", moved > 0.5f)
        val little = places.maxOf { (x, y) -> sharesAt(x, y, 0f).zip(sharesAt(x, y, 0.1f)).maxOf { (a, b) -> abs(a - b) } }
        assertTrue("but nowhere in a tenth of a second: $little", little < 0.25f)
        val frame = places.maxOf { (x, y) -> sharesAt(x, y, 20f).zip(sharesAt(x, y, 20f + 1f / 60)).maxOf { (a, b) -> abs(a - b) } }
        assertTrue("and from one frame to the next it cannot be seen to step: $frame", frame < 0.05f)
    }

    @Test
    fun `a kick pushes the bass in, a voice pushes it back out, and cymbals thicken the top's ribbon`() {
        for (x in listOf(0.1f, 0.5f, 0.9f)) for (above in listOf(true, false)) {
            val still = LivingField.flowVoice(x, 0f, above, 0f, 0f)
            assertTrue(LivingField.flowVoice(x, 0f, above, 0f, 1f) < still - 0.05f)
            assertTrue(LivingField.flowVoice(x, 0f, above, 1f, 0f) > still + 0.05f)
            assertTrue(LivingField.flowTop(x, 0f, 1f) > LivingField.flowTop(x, 0f, 0f) + 0.03f)
        }
        // however hard the kick, the voice keeps some room between the top's ribbon and the bass
        for (x in listOf(0.1f, 0.5f, 0.9f)) {
            val line = LivingField.flowLine(x, 0f)
            val beside = LivingField.flowTop(x, 0f, 0f) + LivingField.FLOW_EDGE / 2 + 0.01f
            assertEquals(listOf(0f, 1f, 0f), sharesAt(x, line + beside, bass = 3f))
            assertEquals(listOf(0f, 1f, 0f), sharesAt(x, line - beside, bass = 3f))
        }
    }

    @Test
    fun `five patches across where the ranges lie in ribbons, and as many along as keeps them round`() {
        assertEquals("a phone upright", 11, LivingField.along(997f, 448f, LivingField.FLOW_ACROSS, LivingField.FLOW_MOST_ALONG))
        assertEquals("the strip in Settings", 11, LivingField.along(380f, 168f, LivingField.FLOW_ACROSS, LivingField.FLOW_MOST_ALONG))
        assertEquals("a square", 5, LivingField.along(600f, 600f, LivingField.FLOW_ACROSS, LivingField.FLOW_MOST_ALONG))
        assertEquals("a picture of the cover keeps its three", 7, LivingField.along(997f, 448f))
        // the top's ribbon is never thinner than a row is tall, so some patch always stands in it
        for (time in listOf(0f, 5f, 17f)) for (x in listOf(0f, 0.25f, 0.5f, 0.75f, 1f)) {
            assertTrue(2 * (LivingField.flowTop(x, time, 0f) - LivingField.FLOW_EDGE / 2) + LivingField.FLOW_EDGE >= 1f / LivingField.FLOW_MOST_ALONG)
        }
    }

    @Test
    fun `colours are mixed by their shares`() {
        val three = intArrayOf(0xff200000.toInt(), 0xff004000.toInt(), 0xff000080.toInt())
        assertEquals(0xff200000.toInt(), LivingField.mixed(three, 0, floatArrayOf(1f, 0f, 0f)))
        assertEquals(0xff102000.toInt(), LivingField.mixed(three, 0, floatArrayOf(0.5f, 0.5f, 0f)))
        assertEquals(0xff081020.toInt(), LivingField.mixed(three, 0, floatArrayOf(0.25f, 0.25f, 0.25f)))
        assertEquals("from further along", 0xff000080.toInt(), LivingField.mixed(intArrayOf(0, 0) + three, 2, floatArrayOf(0f, 0f, 1f)))
    }

    @Test
    fun `a wide picture has no row for the top of the spectrum, so the middle of the voice's row is its`() {
        val (b, m, h) = Triple(MusicLevels.BASS, MusicLevels.MID, MusicLevels.HIGH)
        fun row(row: Int, columns: Int, rows: Int) = (0 until columns).map { LivingField.bandOfCell(it, row, columns, rows) }
        assertEquals("the strip in Settings", listOf(m, m, h, h, h, m, m), row(1, 7, 3))
        assertEquals(listOf(b, b, b, b, b, b, b), row(0, 7, 3))
        assertEquals(listOf(b, b, b, b, b, b, b), row(2, 7, 3))
        assertEquals("a tablet on its side", listOf(m, m, h, m, m), row(1, 5, 3))
        assertEquals("a square has nowhere to put it", listOf(m, m, m), row(1, 3, 3))
        // upright, a patch goes by its row and nothing else
        for (r in 0 until 7) assertEquals(List(3) { LivingField.bandOfRow(r, 7) }, row(r, 3, 7))
    }

    // Moving

    private val frame = 1f / 60

    private fun LivingMotion.run(seconds: Float, bass: Float = 0f, mid: Float = 0f, high: Float = 0f, playing: Boolean = true, measured: Boolean = true) {
        val levels = floatArrayOf(bass, mid, high)
        repeat(Math.round(seconds / frame)) { step(frame, if (measured) levels else null, playing) }
    }

    @Test
    fun `a kick shows at once and lets go slowly`() {
        val motion = motion()
        motion.run(0.05f, bass = 1f)
        assertTrue("three frames into a kick: ${motion.shown[MusicLevels.BASS]}", motion.shown[MusicLevels.BASS] > 0.75f)
        motion.run(0.15f, bass = 0f)
        assertTrue("150 ms after it: ${motion.shown[MusicLevels.BASS]}", motion.shown[MusicLevels.BASS] in 0.35f..0.75f)
        motion.run(1.5f, bass = 0f)
        assertTrue("long after: ${motion.shown[MusicLevels.BASS]}", motion.shown[MusicLevels.BASS] < 0.02f)
    }

    @Test
    fun `the top lets go faster than the bass`() {
        val motion = motion()
        motion.run(0.2f, bass = 1f, high = 1f)
        motion.run(0.2f)
        assertTrue(motion.shown[MusicLevels.HIGH] < motion.shown[MusicLevels.BASS] * 0.6f)
    }

    private val columns = 3
    private val rows = 7
    private fun motion() = LivingMotion(columns, rows)
    private fun LivingMotion.patches() = colors.take(count)

    @Test
    fun `a kick is seen along the top and the bottom, and only a little in the middle`() {
        val motion = motion()
        val bottom = columns * (rows - 1)
        val top = 0
        val middle = columns * 3
        val rest = listOf(bottom, middle, top).associateWith { motion.radius(it) }
        motion.run(0.1f, bass = 1f)
        fun grew(i: Int) = motion.radius(i) / rest.getValue(i) - 1
        assertTrue("bottom ${grew(bottom)}", grew(bottom) > 0.4f)
        assertTrue("top ${grew(top)}", grew(top) > 0.4f)
        assertEquals("as much at one end as at the other", grew(bottom), grew(top), 0.1f)
        assertTrue("the middle is the voice's, it only stirs: ${grew(middle)}", grew(middle) > 0.05f && grew(middle) < grew(bottom) * 0.6f)
    }

    @Test
    fun `a voice moves the rows either side of the middle, the top of the spectrum the very middle at half`() {
        val rest = motion()
        val voice = motion().apply { run(0.25f, mid = 1f) }
        val cymbals = motion().apply { run(0.25f, high = 1f) }
        val kick = motion().apply { run(0.25f, bass = 1f) }
        val bottom = columns * (rows - 1)
        val beside = columns * 2
        val middle = columns * 3
        fun grew(m: LivingMotion, i: Int) = m.radius(i) / rest.radius(i) - 1
        assertTrue("voice ${grew(voice, beside)}", grew(voice, beside) > 0.3f)
        assertTrue("cymbals ${grew(cymbals, middle)}", grew(cymbals, middle) > 0.15f && grew(cymbals, middle) < grew(kick, bottom) * 0.6f)
        assertEquals("neither reaches the bottom row", rest.radius(bottom), voice.radius(bottom), 0.08f)
        assertEquals(rest.radius(bottom), cymbals.radius(bottom), 0.08f)
    }

    @Test
    fun `when not much is going on the picture hardly answers`() {
        fun after(vararg levels: Float) = motion().apply { repeat(30) { step(frame, levels, true) } }
        val full = after(1f, 1f, 1f, 1f)
        val hardly = after(1f, 1f, 1f, 0.15f)
        for (band in 0 until MusicLevels.BANDS) {
            assertEquals("range $band", full.shown[band] * 0.15f, hardly.shown[band], 0.03f)
        }
        val bottom = columns * (rows - 1)
        assertTrue("so a kick in a quiet passage swells a patch a little, not a lot: ${hardly.radius(bottom)} against ${full.radius(bottom)}",
            hardly.radius(bottom) - LivingField.REST_RADIUS < (full.radius(bottom) - LivingField.REST_RADIUS) * 0.3f)
        assertEquals("three levels and no fourth: taken as all there, as it always was", full.shown.toList(), after(1f, 1f, 1f).shown.toList())
        assertEquals("a fourth that is not a number likewise", full.shown.toList(), after(1f, 1f, 1f, Float.NaN).shown.toList())
        val none = after(1f, 1f, 1f, 0f)
        assertTrue("nothing going on, nothing shown", none.shown.all { it == 0f })
    }

    @Test
    fun `a patch on a kick is brighter than at rest, and never brighter than white`() {
        val motion = motion()
        motion.turnTo(IntArray(motion.count) { 0xff808080.toInt() })
        val bottom = columns * (rows - 1)
        val rest = motion.color(bottom) and 0xff
        motion.run(0.1f, bass = 1f)
        val lit = motion.color(bottom) and 0xff
        assertTrue("at rest $rest, on a kick $lit", lit > rest * 1.3f)
        motion.turnTo(IntArray(motion.count) { 0xfff0f0f0.toInt() })
        motion.run(2.5f)
        motion.run(0.1f, bass = 1f)
        assertEquals(0xffffffff.toInt(), motion.color(bottom))
    }

    @Test
    fun `patches stay around their places however long it plays`() {
        val motion = motion()
        repeat(40) {
            motion.run(30f, bass = if (it % 2 == 0) 1f else 0.2f, mid = 0.6f)
            for (i in 0 until motion.count) {
                val homeX = (i % columns + 0.5f) / columns
                val homeY = (i / columns + 0.5f) / rows
                // a quarter of a cell of wandering, and the lean of a full kick on top: at most half the
                // screen away from the middle, pushed out by the lean
                val lean = LivingField.LEAN * LivingField.reach(motion.strength) * 0.6f
                assertTrue("patch $i x ${motion.x(i)}", abs(motion.x(i) - homeX) < LivingField.WANDER / columns + lean)
                assertTrue("patch $i y ${motion.y(i)}", abs(motion.y(i) - homeY) < LivingField.WANDER / rows + lean)
                assertTrue("patch $i radius ${motion.radius(i)}", motion.radius(i) in 0.8f..(0.95f * (1.05f + LivingField.MOST_SWELL)))
            }
        }
    }

    // Hits and levels

    @Test
    fun `a steady loud bass is a glow, and the kick on top of it is what jumps`() {
        val motion = motion()
        motion.run(3f, bass = 0.7f)
        val glow = motion.shown[MusicLevels.BASS]
        assertTrue("held, but well short of full: $glow", glow in 0.2f..0.4f)
        motion.run(0.07f, bass = 1f)
        val kick = motion.shown[MusicLevels.BASS]
        assertTrue("the kick: $kick against $glow", kick > glow + 0.35f)
        motion.run(0.5f, bass = 0.7f)
        assertTrue("and back to the glow: ${motion.shown[MusicLevels.BASS]}", motion.shown[MusicLevels.BASS] < glow + 0.12f)
    }

    @Test
    fun `a loud note held for seconds does not hold the picture at full`() {
        val motion = motion()
        motion.run(0.2f, bass = 1f)
        assertTrue("at first it is a hit: ${motion.shown[MusicLevels.BASS]}", motion.shown[MusicLevels.BASS] > 0.9f)
        motion.run(4f, bass = 1f)
        assertEquals("then it is only loud", LivingField.LEVEL_SHARE, motion.shown[MusicLevels.BASS], 0.05f)
    }

    @Test
    fun `out of silence a kick is a kick`() {
        val motion = motion()
        repeat(6) {
            motion.run(0.42f)
            motion.run(0.08f, bass = 1f)
            assertTrue("kick $it: ${motion.shown[MusicLevels.BASS]}", motion.shown[MusicLevels.BASS] > 0.85f)
        }
    }

    // In time

    @Test
    fun `the picture is started early by what it takes to be seen`() {
        val plain = motion()
        assertEquals(0.063f, plain.lead(), 0.001f)
        val sharp = motion().apply { smoothing = 0f }
        val soft = motion().apply { smoothing = 1f }
        assertTrue("a slow rise is started earlier still: ${sharp.lead()} ${plain.lead()} ${soft.lead()}", sharp.lead() < plain.lead() && plain.lead() < soft.lead())
        assertTrue("never by more than the output holds in its low latency setting, 90 ms, or so little that it lands late",
            sharp.lead() >= 0.045f && soft.lead() <= 0.125f)
    }

    // Changing song

    @Test
    fun `a new cover is turned into slowly at first, then faster, then slowly`() {
        assertEquals(0f, LivingField.eased(0f), 0f)
        assertEquals(1f, LivingField.eased(1f), 0f)
        assertEquals(0.5f, LivingField.eased(0.5f), 0.0001f)
        assertTrue(LivingField.eased(0.1f) < 0.03f && LivingField.eased(0.9f) > 0.97f)
        assertEquals(1f, LivingField.eased(4f), 0f)

        val black = 0xff000000.toInt()
        val white = 0xffffffff.toInt()
        val motion = motion()
        motion.turnTo(IntArray(motion.count) { black })
        motion.turnTo(IntArray(motion.count) { white })
        fun shade() = motion.colors[0] and 0xff
        val whole = LivingField.COVER_TURN
        motion.run(whole * 0.1f)
        assertTrue("a tenth of the time in, hardly begun: ${shade()}", shade() in 1..12)
        motion.run(whole * 0.4f)
        assertTrue("half way through, half way there: ${shade()}", shade() in 110..145)
        motion.run(whole * 0.4f)
        assertTrue("nearly there, and slowing: ${shade()}", shade() in 243..254)
        assertFalse(motion.colors[0] == white)
        motion.run(whole * 0.15f)
        assertEquals(white, motion.colors[0])
    }

    @Test
    fun `a cover arriving while another is being turned into starts from what is on screen`() {
        val motion = motion()
        motion.turnTo(IntArray(motion.count) { red })
        motion.turnTo(IntArray(motion.count) { blue })
        motion.run(LivingField.COVER_TURN / 2)
        val onScreen = motion.colors[0]
        assertTrue(onScreen != red && onScreen != blue)
        motion.turnTo(IntArray(motion.count) { green })
        motion.step(0f, null, true)
        assertEquals("no jump", onScreen, motion.colors[0])
        motion.run(LivingField.COVER_TURN + 0.1f)
        assertEquals(green, motion.colors[0])
    }

    // How strongly

    private fun kicked(strength: Float) = motion().apply {
        this.strength = strength
        turnTo(IntArray(count) { 0xff806040.toInt() })
        run(0.3f, bass = 1f, mid = 1f, high = 1f)
    }

    @Test
    fun `the setting starts in the middle, where the picture answers half again as much as it first did`() {
        assertEquals(1.5f, LivingField.reach(LivingField.DEFAULT_STRENGTH), 0f)
        assertEquals(3f, LivingField.reach(1f), 0f)
        assertEquals(0f, LivingField.reach(0f), 0f)
        assertEquals("nothing above the top", 3f, LivingField.reach(7f), 0f)
        assertEquals("nothing below the bottom", 0f, LivingField.reach(-1f), 0f)
        assertEquals("a setting that is not a number is the middle", 1.5f, LivingField.reach(Float.NaN), 0f)
        assertEquals(LivingField.DEFAULT_STRENGTH, LivingMotion().strength, 0f)
    }

    @Test
    fun `turned right down, a kick moves nothing`() {
        val still = motion().apply { turnTo(IntArray(count) { 0xff806040.toInt() }) }
        val bottom = columns * (rows - 1)
        val rest = Triple(still.radius(bottom), still.color(bottom), still.x(bottom))
        val restGlow = still.glowStrength()
        val restAura = still.auraRadius(0)
        val off = kicked(0f)
        // the ripple and the wander still run with the music, so compared loosely
        assertEquals(rest.first, off.radius(bottom), 0.08f)
        assertEquals(rest.second, off.color(bottom))
        assertEquals(restGlow, off.glowStrength(), 0f)
        assertEquals(restAura, off.auraRadius(0), 0f)
    }

    @Test
    fun `turned up, the same kick swells, lights and pushes more`() {
        val bottom = columns * (rows - 1)
        val low = kicked(0.25f)
        val middle = kicked(0.5f)
        val high = kicked(1f)
        assertTrue(low.radius(bottom) < middle.radius(bottom) && middle.radius(bottom) < high.radius(bottom))
        assertTrue((low.color(bottom) shr 16 and 0xff) < (middle.color(bottom) shr 16 and 0xff))
        assertTrue(low.glowStrength() < middle.glowStrength() && middle.glowStrength() < high.glowStrength())
        assertTrue(low.auraRadius(0) < middle.auraRadius(0) && middle.auraRadius(0) < high.auraRadius(0))
        // a corner patch is pushed further out
        assertTrue(abs(low.x(bottom) - 0.5f) < abs(high.x(bottom) - 0.5f))
    }

    @Test
    fun `turned all the way up it still stays inside its limits`() {
        val most = kicked(1f)
        for (i in 0 until most.count) {
            assertTrue("radius ${most.radius(i)}", most.radius(i) <= LivingField.REST_RADIUS * (1.05f + LivingField.MOST_SWELL))
            assertTrue("x ${most.x(i)}", most.x(i) in -0.15f..1.15f)
            assertTrue("y ${most.y(i)}", most.y(i) in -0.15f..1.15f)
        }
        for (i in most.aura.indices) {
            assertTrue("aura radius ${most.auraRadius(i)}", most.auraRadius(i) <= LivingField.AURA_MOST)
            assertTrue("aura strength ${most.auraStrength(i)}", most.auraStrength(i) in 0f..1f)
        }
        assertTrue(most.glowStrength() <= 1f && most.glowHeight() <= 0.8f)
    }

    @Test
    fun `a beat makes a colour stronger, not paler`() {
        val orange = 0xffc06020.toInt()
        val motion = motion().apply { strength = 1f; turnTo(IntArray(count) { orange }) }
        val bottom = columns * (rows - 1)
        motion.run(0.3f, bass = 1f)
        val lit = motion.color(bottom)
        val (r, g, b) = Triple(lit shr 16 and 0xff, lit shr 8 and 0xff, lit and 0xff)
        assertTrue("brighter: $r", r > 0xc0)
        assertTrue("and still orange, with blue well under red: $r $g $b", b < r / 2 && g < r)
    }

    // How softly

    @Test
    fun `the smoothing setting starts in the middle, where times are what they are`() {
        assertEquals(1f, LivingField.ease(LivingField.DEFAULT_SMOOTHING), 0.0001f)
        assertEquals(0.25f, LivingField.ease(0f), 0.0001f)
        assertEquals(4f, LivingField.ease(1f), 0.0001f)
        assertEquals(4f, LivingField.ease(9f), 0.0001f)
        assertEquals(0.25f, LivingField.ease(-2f), 0.0001f)
        assertEquals(1f, LivingField.ease(Float.NaN), 0f)
        assertEquals(LivingField.DEFAULT_SMOOTHING, LivingMotion().smoothing, 0f)
    }

    @Test
    fun `turned down it jumps with a kick and drops it at once, turned up it swells and lingers`() {
        fun after(smoothing: Float, kick: Float, gap: Float) = motion().apply {
            this.smoothing = smoothing
            run(kick, bass = 1f)
            if (gap > 0f) run(gap)
        }.shown[MusicLevels.BASS]

        // one frame and a bit into a kick
        val sharp = after(0f, 0.035f, 0f)
        val plain = after(0.5f, 0.035f, 0f)
        val soft = after(1f, 0.035f, 0f)
        assertTrue("sharp $sharp, plain $plain, soft $soft", sharp > 0.9f && plain in 0.5f..0.9f && soft < 0.35f)

        // a kick held for a third of a second, then a fifth of a second of nothing
        val sharpLeft = after(0f, 0.3f, 0.2f)
        val plainLeft = after(0.5f, 0.3f, 0.2f)
        val softLeft = after(1f, 0.3f, 0.2f)
        assertTrue("sharp $sharpLeft, plain $plainLeft, soft $softLeft", sharpLeft < 0.1f && plainLeft in 0.35f..0.65f && softLeft > 0.7f)
    }

    @Test
    fun `the aura is smoothed with the rest`() {
        fun underCover(smoothing: Float) = motion().apply {
            this.smoothing = smoothing
            run(0.05f, bass = 1f)
        }.let { m -> m.auraShown[m.aura.indexOfFirst { it.y == 1f && it.x == 0.5f }] }
        assertTrue(underCover(0f) > underCover(0.5f) && underCover(0.5f) > underCover(1f))
    }

    // Round the cover

    @Test
    fun `the aura has a point for every patch on the rim, each on the cover's edge`() {
        val aura = LivingField.aura(columns, rows)
        assertEquals(2 * rows + 2 * columns, aura.size)
        for (point in aura) {
            assertTrue("on an edge: ${point.x}, ${point.y}", point.x == 0f || point.x == 1f || point.y == 0f || point.y == 1f)
            assertTrue(point.x in 0f..1f && point.y in 0f..1f)
            val column = point.patch % columns
            val row = point.patch / columns
            assertTrue("a rim patch", column == 0 || column == columns - 1 || row == 0 || row == rows - 1)
            // and the one beside it: the left edge takes the left column, the top edge the top row
            if (point.x == 0f) assertEquals(0, column)
            if (point.x == 1f) assertEquals(columns - 1, column)
            if (point.y == 0f) assertEquals(0, row)
            if (point.y == 1f) assertEquals(rows - 1, row)
        }
    }

    @Test
    fun `the aura follows the bass along the cover's top and bottom, and the higher ranges down its sides`() {
        for (point in LivingField.aura(columns, rows)) {
            if (point.y == 0f || point.y == 1f) assertEquals(MusicLevels.BASS, point.band)
            else assertTrue(point.band == MusicLevels.MID || point.band == MusicLevels.HIGH)
        }
        assertTrue("the top of the spectrum has the middle of each side", LivingField.aura(columns, rows).any { it.band == MusicLevels.HIGH })
    }

    @Test
    fun `a kick lands above and below the cover and runs round to the middle of its sides`() {
        val aura = LivingField.aura(columns, rows)
        val bottomMiddle = aura.indexOfFirst { it.y == 1f && it.x == 0.5f }
        val topMiddle = aura.indexOfFirst { it.y == 0f && it.x == 0.5f }
        val sideMiddle = aura.indexOfFirst { it.x == 0f && it.y == 0.5f }
        assertEquals(0f, aura[bottomMiddle].far, 0.001f)
        assertEquals(0f, aura[topMiddle].far, 0.001f)
        assertEquals(1f, aura[sideMiddle].far, 0.001f)
        assertTrue(aura.all { it.far in 0f..1f })

        val motion = motion()
        motion.run(0.05f, bass = 1f)
        assertTrue("above and below first: ${motion.auraShown[bottomMiddle]} against ${motion.auraShown[sideMiddle]}",
            motion.auraShown[bottomMiddle] > motion.auraShown[sideMiddle] + 0.25f)
        assertEquals(motion.auraShown[bottomMiddle], motion.auraShown[topMiddle], 0.001f)
        motion.run(0.25f, bass = 1f)
        assertTrue("then all the way round: ${motion.auraShown[sideMiddle]}", motion.auraShown[sideMiddle] > 0.75f)
    }

    @Test
    fun `at rest the aura is a thin halo, and on a kick it reaches out`() {
        val motion = motion().apply { coverThere = true; settle() }
        assertEquals(LivingField.AURA_REST, motion.auraRadius(0), 0f)
        assertTrue("it is there at rest: ${motion.auraStrength(0)}", motion.auraStrength(0) in 0.2f..0.4f)
        motion.run(0.4f, bass = 1f)
        assertTrue("${motion.auraRadius(0)}", motion.auraRadius(0) > LivingField.AURA_REST * 2.5f)
        assertTrue(motion.auraStrength(0) > 0.7f)
    }

    @Test
    fun `the aura goes with the cover and comes back with it`() {
        val motion = motion().apply { coverThere = true; settle() }
        assertEquals(1f, motion.auraPresence, 0f)
        motion.coverThere = false                              // the lyrics are up, there is no cover to stand round
        assertFalse("it has to be seen to go", motion.atRest())
        motion.run(1f, playing = false, measured = false)
        assertTrue("${motion.auraPresence}", motion.auraPresence < 0.01f)
        assertEquals(0f, motion.auraStrength(0), 0.01f)
        assertTrue(motion.atRest())
        motion.coverThere = true
        assertFalse(motion.atRest())
        motion.run(1f, playing = false, measured = false)
        assertTrue(motion.auraPresence > 0.99f && motion.atRest())
    }

    // A colour to each range: each moves its own colour and no other

    private val ofBass = 0xff780000.toInt()
    private val ofVoice = 0xff007800.toInt()
    private val ofTop = 0xff000078.toInt()

    /**
     * A picture in ribbons, the bass's colour all red, the voice's all green and the top's all
     * blue: a patch's red is then the bass's doing and nobody else's, and so on.
     */
    private fun apart() = LivingMotion(LivingField.FLOW_ACROSS, LivingField.FLOW_MOST_ALONG).apply {
        separate = true
        turnTo(IntArray(count) { ofBass }, glow = ofBass, mains = intArrayOf(ofBass, ofVoice, ofTop))
    }

    private fun LivingMotion.sharesOfPatch(i: Int): List<Float> =
        FloatArray(3).also { sharesAt((i % columns + 0.5f) / columns, (i / columns + 0.5f) / rows, it) }.toList()

    /** The patch that is most [band]'s. */
    private fun LivingMotion.patchOf(band: Int): Int = (0 until count).maxBy { sharesOfPatch(it)[band] }

    /** How brightly [band]'s own colour is lit at patch [i], whatever share of the patch it has. */
    private fun LivingMotion.lightOf(band: Int, i: Int): Float {
        val channel = (color(i) shr (16 - 8 * band)) and 0xff
        return channel / (sharesOfPatch(i)[band] * grain(i))
    }

    /** Where the player has the cover on a phone held upright, in parts of the screen. */
    private fun LivingMotion.coverAsInThePlayer() = apply { coverThere = true; coverAt(0.083f, 0.097f, 0.917f, 0.48f) }

    @Test
    fun `at rest a patch is its place's mix of the three colours`() {
        val motion = apart()
        val (bass, voice, top) = Triple(motion.patchOf(MusicLevels.BASS), motion.patchOf(MusicLevels.MID), motion.patchOf(MusicLevels.HIGH))
        assertEquals("a corner is all the bass's", listOf(1f, 0f, 0f), motion.sharesOfPatch(0))
        assertEquals(listOf(1f, 0f, 0f), motion.sharesOfPatch(motion.count - 1))
        assertTrue("some patch is nearly all the voice's: ${motion.sharesOfPatch(voice)}", motion.sharesOfPatch(voice)[1] > 0.9f)
        assertTrue("and one nearly all the top's: ${motion.sharesOfPatch(top)}", motion.sharesOfPatch(top)[2] > 0.9f)
        fun channels(i: Int) = motion.color(i).let { listOf(it shr 16 and 0xff, it shr 8 and 0xff, it and 0xff) }
        assertTrue("red and nothing else: ${channels(bass)}", channels(bass).let { it[0] > 60 && it[1] == 0 && it[2] == 0 })
        assertTrue("mostly green: ${channels(voice)}", channels(voice).let { it[1] > 4 * it[0] && it[1] > 4 * it[2] })
        assertTrue("mostly blue: ${channels(top)}", channels(top).let { it[2] > 4 * it[0] && it[2] > 4 * it[1] })
        // a ribbon is not one flat colour
        assertTrue((0 until motion.columns).map { motion.color(it) }.toSet().size > 1)
    }

    @Test
    fun `a kick moves what is the bass's and leaves the top's line alone`() {
        val rest = apart()
        val kick = apart().apply { run(0.1f, bass = 1f) }
        val top = rest.patchOf(MusicLevels.HIGH)
        fun grew(i: Int) = kick.radius(i) / rest.radius(i) - 1
        assertTrue("a corner swells: ${grew(0)}", grew(0) > 0.4f)
        assertTrue("so does the one opposite: ${grew(rest.count - 1)}", grew(rest.count - 1) > 0.4f)
        assertEquals("the top's own patch does not stir", 0f, grew(top), 0.03f)
        assertEquals("nor light up", rest.lightOf(MusicLevels.HIGH, top), kick.lightOf(MusicLevels.HIGH, top), 2f)
        assertTrue("the bass's colour does: ${kick.lightOf(MusicLevels.BASS, 0)} from ${rest.lightOf(MusicLevels.BASS, 0)}",
            kick.lightOf(MusicLevels.BASS, 0) > rest.lightOf(MusicLevels.BASS, 0) * 1.3f)
        // and it comes in: the patches on the edge of the voice's ribbon turn the bass's
        val before = (0 until rest.count).sumOf { rest.sharesOfPatch(it)[0].toDouble() }
        val after = (0 until kick.count).sumOf { kick.sharesOfPatch(it)[0].toDouble() }
        assertTrue("the bass has more of the picture on a kick: $after against $before", after > before + 2.0)
    }

    @Test
    fun `the bass pushes, the voice glows and the top glints`() {
        val rest = apart()
        fun heard(bass: Float = 0f, mid: Float = 0f, high: Float = 0f) = apart().apply { run(0.25f, bass, mid, high) }
        val kick = heard(bass = 1f)
        val voice = heard(mid = 1f)
        val cymbals = heard(high = 1f)
        val (ofTheBass, ofTheVoice, ofTheTop) = Triple(0, rest.patchOf(MusicLevels.MID), rest.patchOf(MusicLevels.HIGH))
        fun grew(m: LivingMotion, i: Int) = m.radius(i) / rest.radius(i) - 1
        fun lit(m: LivingMotion, band: Int, i: Int) = m.lightOf(band, i) / rest.lightOf(band, i)
        assertTrue("each swells less than the one below it: ${grew(kick, ofTheBass)}, ${grew(voice, ofTheVoice)}, ${grew(cymbals, ofTheTop)}",
            grew(kick, ofTheBass) > grew(voice, ofTheVoice) * 1.2f && grew(voice, ofTheVoice) > grew(cymbals, ofTheTop) * 1.2f)
        assertTrue("the top still moves: ${grew(cymbals, ofTheTop)}", grew(cymbals, ofTheTop) > 0.05f)
        val lights = listOf(lit(kick, MusicLevels.BASS, ofTheBass), lit(voice, MusicLevels.MID, ofTheVoice), lit(cymbals, MusicLevels.HIGH, ofTheTop))
        assertTrue("and each is lit more than the one below it: $lights", lights[2] > lights[1] && lights[1] > lights[0] && lights[0] > 1.3f)
        assertEquals("a voice does not light the bass's colour", 1f, lit(voice, MusicLevels.BASS, ofTheBass), 0.03f)
        assertEquals("nor cymbals the voice's", 1f, lit(cymbals, MusicLevels.MID, ofTheVoice), 0.06f)
    }

    @Test
    fun `a range that is quiet sits darker than the bass does, so that it is seen to come in`() {
        val quiet = apart()
        val bass = quiet.lightOf(MusicLevels.BASS, 0)
        val voice = quiet.lightOf(MusicLevels.MID, quiet.patchOf(MusicLevels.MID))
        val top = quiet.lightOf(MusicLevels.HIGH, quiet.patchOf(MusicLevels.HIGH))
        assertTrue("$bass, $voice, $top", bass > voice + 2 && voice > top + 2)
        assertTrue("not dark, only darker", top > bass * 0.8f)
    }

    @Test
    fun `a held voice is seen for as long as it is held`() {
        val kept = apart().apply { run(4f, mid = 0.8f) }
        val whole = motion().apply { run(4f, mid = 0.8f) }
        assertEquals(LivingField.OWN_LEVEL[MusicLevels.MID] * 0.8f, kept.shown[MusicLevels.MID], 0.03f)
        assertEquals(LivingField.LEVEL_SHARE * 0.8f, whole.shown[MusicLevels.MID], 0.03f)
        assertTrue(kept.shown[MusicLevels.MID] > whole.shown[MusicLevels.MID] * 1.3f)
    }

    @Test
    fun `the ribbons flow while the music plays and stand still when it has stopped`() {
        val motion = apart()
        val places = (0 until motion.count)
        fun now() = places.map { motion.sharesOfPatch(it) }
        val first = now()
        motion.run(8f, bass = 0.3f, mid = 0.3f, high = 0.3f)
        val later = now()
        assertTrue("eight seconds of music on, patches have changed hands", first.zip(later).maxOf { (a, b) -> a.zip(b).maxOf { (x, y) -> abs(x - y) } } > 0.4f)
        motion.run(6f, playing = false, measured = false)
        val stopped = now()
        motion.run(3f, playing = false, measured = false)
        assertTrue("three seconds of nothing on, none has", stopped.zip(now()).all { (a, b) -> a.zip(b).all { (x, y) -> abs(x - y) < 0.001f } })
        assertTrue(motion.atRest())
    }

    @Test
    fun `the halo takes its colour and its range from the ribbons it stands on`() {
        val motion = apart().coverAsInThePlayer()
        val aura = motion.aura
        val topMiddle = aura.indexOfFirst { it.y == 0f && abs(it.x - 0.5f) < 0.11f }
        fun channels(color: Int) = listOf(color shr 16 and 0xff, color shr 8 and 0xff, color and 0xff)
        // each point lights in the mix of the place it stands on
        val place = FloatArray(3)
        for (i in aura.indices) {
            motion.sharesAt(0.083f + aura[i].x * 0.834f, 0.097f + aura[i].y * 0.383f, place)
            val most = place.indices.maxBy { place[it] }
            if (place[most] > 0.8f) assertEquals("point at ${aura[i].x}, ${aura[i].y}: ${channels(motion.auraColor(i))}", most, channels(motion.auraColor(i)).let { c -> c.indices.maxBy { c[it] } })
        }
        assertEquals("the cover's top edge stands in the bass", 0, channels(motion.auraColor(topMiddle)).let { c -> c.indices.maxBy { c[it] } })
        assertTrue("and somewhere down its sides or along its bottom the halo is another range's",
            aura.indices.any { i -> channels(motion.auraColor(i)).let { c -> c.indices.maxBy { c[it] } } != 0 })

        // long enough at one level, a point is taken as far as the ranges it stands on are, each for its share
        motion.run(4f, bass = 0.6f, mid = 0.2f, high = 0.9f)
        for (i in aura.indices) {
            motion.sharesAt(0.083f + aura[i].x * 0.834f, 0.097f + aura[i].y * 0.383f, place)
            val want = (0 until 3).sumOf { (place[it] * motion.shown[it] * LivingField.OWN_SHARE[it]).toDouble() }.toFloat()
            assertEquals("point at ${aura[i].x}, ${aura[i].y}", want, motion.auraShown[i], 0.06f)
        }
        val kick = apart().coverAsInThePlayer().apply { run(0.3f, bass = 1f) }
        assertTrue("a kick reaches out above the cover: ${kick.auraShown[topMiddle]}", kick.auraShown[topMiddle] > 0.7f)

        val whole = motion().coverAsInThePlayer().apply { turnTo(IntArray(count) { 0xff000000.toInt() or (it * 9) }) }
        for (i in whole.aura.indices) {
            val want = LivingField.lit(LivingField.colourful(whole.colors[whole.aura[i].patch], 1.15f), 1f)
            assertEquals("a picture of the cover: the colour of the part of the cover beside it", want, whole.auraColor(i))
        }
    }

    @Test
    fun `a cover that fills the picture or is off it still gives the halo a colour`() {
        val motion = apart().apply { coverThere = true; coverAt(-0.4f, -0.2f, 1.6f, 1.3f) }
        motion.run(0.2f, bass = 1f, mid = 1f, high = 1f)
        assertTrue(motion.auraShown.all { it.isFinite() && it in 0f..1.01f })
        for (i in motion.aura.indices) assertTrue(motion.auraColor(i) ushr 24 == 0xff)
    }

    @Test
    fun `the glow takes the bass's own colour when it is given one`() {
        val patches = IntArray(columns * rows) { 0xff202020.toInt() }.also { it[4] = 0xff10c040.toInt() }
        val given = motion().apply { turnTo(patches, glow = 0xffc01030.toInt()) }
        assertEquals(LivingField.lit(0xffc01030.toInt(), LivingField.GLOW_LIGHT), given.glow)
        val left = motion().apply { turnTo(patches) }
        assertEquals("left out, the strongest patch", LivingField.lit(0xff10c040.toInt(), LivingField.GLOW_LIGHT), left.glow)
    }

    @Test
    fun `the three colours turn into the next cover's as the rest does`() {
        val motion = apart()
        val next = intArrayOf(0xff004080.toInt(), 0xff808000.toInt(), 0xffe0e0e0.toInt())
        motion.turnTo(IntArray(motion.count) { next[0] }, glow = next[0], mains = next)
        val at = motion.count + 2
        assertEquals("not at once", ofBass, motion.colors[at])
        motion.run(LivingField.COVER_TURN / 2)
        assertTrue("half way there: ${Integer.toHexString(motion.colors[at])}", (motion.colors[at] shr 16 and 0xff) in 0x20..0x58 && (motion.colors[at] and 0xff) in 0x28..0x60)
        motion.run(LivingField.COVER_TURN)
        assertEquals(next.toList(), motion.colors.slice(at until at + 3))
    }

    @Test
    fun `with the music stopped it comes to rest and stays there`() {
        val motion = motion()
        motion.run(3f, bass = 0.8f, mid = 0.5f, high = 0.3f)
        assertFalse(motion.atRest())
        motion.run(6f, playing = false, measured = false)
        assertTrue("pace ${motion.pace}, shown ${motion.shown.toList()}", motion.atRest())
        val x = motion.x(5)
        val y = motion.y(5)
        motion.run(20f, playing = false, measured = false)
        assertEquals(x, motion.x(5), 0.002f)
        assertEquals(y, motion.y(5), 0.002f)
    }

    @Test
    fun `music that cannot be measured still drifts, it just does not breathe`() {
        val motion = motion()
        motion.run(5f, measured = false)
        val before = motion.drift
        motion.run(5f, measured = false)
        assertTrue("drift went from $before to ${motion.drift}", motion.drift > before + 1f)
        assertArrayEquals(floatArrayOf(0f, 0f, 0f), motion.shown, 0f)
        assertFalse(motion.atRest())
    }

    @Test
    fun `the first cover is there at once, the next one is turned into`() {
        val motion = motion()
        motion.turnTo(IntArray(motion.count) { red })
        assertTrue(motion.patches().all { it == red })
        motion.turnTo(IntArray(motion.count) { blue })
        assertTrue("not switched in one go", motion.patches().all { it == red })
        motion.run(0.2f)
        assertTrue("on the way: ${Integer.toHexString(motion.colors[0])}", motion.colors[0] != red && motion.colors[0] != blue)
        motion.run(4f)
        assertTrue("arrived exactly, or the frames would never stop: ${Integer.toHexString(motion.colors[0])}", motion.patches().all { it == blue })
    }

    @Test
    fun `what lies under the patches and the glow turn with the cover too`() {
        val motion = motion()
        motion.turnTo(IntArray(motion.count) { red })
        assertEquals(LivingField.lit(red, LivingField.REST_LIGHT), motion.under)
        assertEquals(LivingField.lit(red, LivingField.GLOW_LIGHT), motion.glow)
        motion.turnTo(IntArray(motion.count) { if (it == 4) green else dark })
        assertEquals("not in one go", LivingField.lit(red, LivingField.GLOW_LIGHT), motion.glow)
        motion.run(4f)
        assertEquals("the one lit patch of a dark cover", LivingField.lit(green, LivingField.GLOW_LIGHT), motion.glow)
        assertTrue(motion.atRest().not())                       // it still plays
        motion.run(6f, playing = false, measured = false)
        assertTrue(motion.atRest())
    }

    @Test
    fun `a cover with too few patches is filled up, not read past its end`() {
        val motion = motion()
        motion.turnTo(intArrayOf(red, blue))
        assertEquals(red, motion.colors[0])
        assertEquals(blue, motion.colors[1])
        assertEquals(LivingField.GREY, motion.colors[motion.count - 1])
    }

    @Test
    fun `told to be still, it is, with the new cover's colours`() {
        val motion = motion()
        motion.turnTo(IntArray(motion.count) { red })
        motion.run(2f, bass = 1f, mid = 1f)
        motion.turnTo(IntArray(motion.count) { blue })
        motion.settle()
        assertTrue(motion.atRest())
        assertTrue(motion.patches().all { it == blue })
    }

    // The song's shape: gathered by a build-up, one burst on the drop, more of everything after it

    /** Steps on with nothing but a kick or none in the levels, all there, and this much of the song's shape. */
    private fun LivingMotion.shaped(seconds: Float, tension: Float = 0f, drop: Float = 0f, drive: Float = 0f, bass: Float = 0f, going: Float = 1f) {
        val levels = floatArrayOf(bass, 0f, 0f, going, tension, drop, drive)
        repeat(Math.round(seconds / frame)) { step(frame, levels, true) }
    }

    /**
     * The first [seconds] of a drop as the analyser gives it: a kick of 80 ms, the drop at
     * [strength] in its first frame and fading from there, and the drive on. Returns the burst at
     * every step.
     */
    private fun LivingMotion.dropped(seconds: Float, strength: Float = 1f, drive: Float = 1f, going: Float = 1f): List<Float> =
        List(Math.round(seconds / frame)) { n ->
            val drop = (strength * exp(-n * frame / 0.15f)).let { if (it < 0.01f) 0f else it }
            step(frame, floatArrayOf(if (n * frame < 0.08f) 1f else 0f, 0f, 0f, going, 0f, drop, drive), true)
            burst
        }

    private fun LivingMotion.meanRadius() = (0 until count).map { radius(it) }.average().toFloat()

    @Test
    fun `a build-up gathers the picture, in either way of colouring`() {
        for (ribbons in listOf(false, true)) {
            fun fresh() = if (ribbons) apart() else motion().apply { turnTo(IntArray(count) { 0xff806040.toInt() }) }
            val calm = fresh().apply { shaped(4f) }
            val tense = fresh().apply { shaped(4f, tension = 1f) }
            assertEquals("ribbons $ribbons", 1f, tense.gathered, 0.01f)
            assertEquals(0f, calm.gathered, 0f)
            val reach = LivingField.reach(tense.strength)
            assertEquals("everything stands nearer the middle", 1f - LivingField.GATHER_IN * reach, tense.push(), 0.002f)
            assertEquals(1f, calm.push(), 0f)
            assertTrue("and is smaller: ${tense.meanRadius()} against ${calm.meanRadius()}", tense.meanRadius() < calm.meanRadius() * 0.96f)
            assertTrue("and flows faster: ${tense.drift} against ${calm.drift}", tense.drift > calm.drift * 1.5f)
            assertEquals("no burst, no drive", 0f, tense.burst + tense.driven, 0f)
        }
    }

    @Test
    fun `tension comes on slowly and is let go of at once`() {
        val motion = motion()
        motion.shaped(0.2f, tension = 1f)
        assertTrue("a fifth of a second in: ${motion.gathered}", motion.gathered in 0.15f..0.4f)
        motion.shaped(3f, tension = 1f)
        motion.shaped(0.2f)
        assertTrue("a fifth of a second after the drop took it: ${motion.gathered}", motion.gathered < 0.25f)
    }

    @Test
    fun `a build-up charges the top of the spectrum`() {
        // with a colour to each range: the top's ribbon is thicker and lit
        val calm = apart().apply { shaped(4f) }
        val tense = apart().apply { shaped(4f, tension = 1f) }
        fun ofTheTop(m: LivingMotion) = (0 until m.count).sumOf { m.sharesOfPatch(it)[MusicLevels.HIGH].toDouble() }
        assertTrue("the top has more of the picture: ${ofTheTop(tense)} against ${ofTheTop(calm)}", ofTheTop(tense) > ofTheTop(calm) * 1.15)
        val lit = tense.lightOf(MusicLevels.HIGH, tense.patchOf(MusicLevels.HIGH)) / calm.lightOf(MusicLevels.HIGH, calm.patchOf(MusicLevels.HIGH))
        assertTrue("and its colour is lit: $lit", lit > 1.3f)
        assertEquals("the bass's is not", calm.lightOf(MusicLevels.BASS, 0), tense.lightOf(MusicLevels.BASS, 0), 2f)

        // as a picture of the cover: the very middle row, which is the top's
        val grey = IntArray(columns * rows) { 0xff606060.toInt() }
        val still = motion().apply { turnTo(grey); shaped(4f) }
        val charged = motion().apply { turnTo(grey); shaped(4f, tension = 1f) }
        val middle = columns * 3
        assertTrue("${charged.color(middle) and 0xff} against ${still.color(middle) and 0xff}", (charged.color(middle) and 0xff) > (still.color(middle) and 0xff) * 1.2f)
        assertEquals("the bass's rows are as they were", still.color(0), charged.color(0))
    }

    @Test
    fun `the drop is one burst, on the beat`() {
        val motion = motion().apply { shaped(3f, tension = 1f) }
        val burst = motion.dropped(2f)
        val peak = burst.indices.maxBy { burst[it] }
        assertTrue("it is there within a tenth of a second: ${burst.take(7)}", burst[5] > 0.8f)
        assertTrue("at its most ${peak * frame} s in: ${burst[peak]}", peak <= 7 && burst[peak] > 0.9f)
        assertTrue("then it only goes", burst.drop(peak).zipWithNext().all { (a, b) -> b <= a })
        assertTrue("half a second on, most of it has: ${burst[30 + peak]}", burst[30 + peak] in 0.15f..0.5f)
        assertTrue("two seconds on, all of it: ${burst.last()}", burst.last() < 0.02f)
        // the part it set off goes on, kick after kick, and there is no second burst
        repeat(8) {
            motion.shaped(0.08f, drive = 1f, bass = 1f)
            motion.shaped(0.42f, drive = 1f)
            assertTrue("kick $it: ${motion.burst}", motion.burst < 0.02f)
        }
        assertEquals(1f, motion.driven, 0.01f)
    }

    @Test
    fun `a drop pushes everything out, lights everything and reaches round the cover, as a kick alone does not`() {
        val kick = motion().coverAsInThePlayer().apply { turnTo(IntArray(count) { 0xff606060.toInt() }); shaped(0.08f, bass = 1f) }
        val drop = motion().coverAsInThePlayer().apply { turnTo(IntArray(count) { 0xff606060.toInt() }); dropped(0.08f, drive = 0f) }
        assertTrue("pushed out: ${drop.push()} against ${kick.push()}", drop.push() - 1f > (kick.push() - 1f) * 1.8f)
        val middle = columns * 2                                  // a row of the voice's, which a kick only stirs
        assertTrue("the voice's rows swell: ${drop.radius(middle)} against ${kick.radius(middle)}", drop.radius(middle) > kick.radius(middle) * 1.2f)
        assertTrue("and are lit: ${drop.color(middle) and 0xff} against ${kick.color(middle) and 0xff}", (drop.color(middle) and 0xff) > (kick.color(middle) and 0xff) * 1.3f)
        assertTrue("the bass's own rows are lit more than by the kick", (drop.color(0) and 0xff) > (kick.color(0) and 0xff))
        assertTrue("the glow stands taller and stronger", drop.glowHeight() > kick.glowHeight() && drop.glowStrength() > kick.glowStrength())
        val side = drop.aura.indexOfFirst { it.x == 0f && abs(it.y - 0.5f) < 0.1f }
        kick.shaped(0.1f)
        drop.dropped(0.1f, strength = 0.5f, drive = 0f)           // what is left of it by then, more or less
        assertTrue("the halo reaches out half way down the cover's sides: ${drop.auraShown[side]} against ${kick.auraShown[side]}", drop.auraShown[side] > kick.auraShown[side] + 0.2f)
    }

    @Test
    fun `on a drop the bass floods in over the other two`() {
        val kick = apart().apply { shaped(0.08f, bass = 1f) }
        val drop = apart().apply { dropped(0.08f, drive = 0f) }
        fun ofTheBass(m: LivingMotion) = (0 until m.count).sumOf { m.sharesOfPatch(it)[MusicLevels.BASS].toDouble() }
        assertTrue("it has more of the picture than on a kick: ${ofTheBass(drop)} against ${ofTheBass(kick)}", ofTheBass(drop) > ofTheBass(kick) + 2.0)
        val top = drop.patchOf(MusicLevels.HIGH)
        assertTrue("the top keeps its line: ${drop.sharesOfPatch(top)}", drop.sharesOfPatch(top)[MusicLevels.HIGH] > 0.9f)
        assertTrue("and that line is lit with the rest, this once: ${drop.lightOf(MusicLevels.HIGH, top)} against ${kick.lightOf(MusicLevels.HIGH, kick.patchOf(MusicLevels.HIGH))}",
            drop.lightOf(MusicLevels.HIGH, top) > kick.lightOf(MusicLevels.HIGH, kick.patchOf(MusicLevels.HIGH)) * 1.3f)
        assertTrue("every patch swells", (0 until drop.count).all { drop.radius(it) > kick.radius(it) })
    }

    @Test
    fun `a stronger drop is a bigger burst`() {
        val small = motion().apply { dropped(0.1f, strength = 0.5f) }
        val big = motion().apply { dropped(0.1f, strength = 1f) }
        assertEquals(2f, big.burst / small.burst, 0.1f)
        assertTrue(big.push() > small.push())
    }

    @Test
    fun `while the drive lasts everything is bigger and answers more, and when it goes it is as it was`() {
        for (ribbons in listOf(false, true)) {
            fun fresh() = if (ribbons) apart() else motion().apply { turnTo(IntArray(count) { 0xff604030.toInt() }) }
            val plain = fresh().apply { shaped(3f) }
            val driven = fresh().apply { shaped(3f, drive = 1f) }
            assertEquals(1f, driven.driven, 0.01f)
            assertTrue("ribbons $ribbons, bigger between two kicks: ${driven.meanRadius()} against ${plain.meanRadius()}", driven.meanRadius() > plain.meanRadius() * 1.05f)
            assertTrue("flowing faster: ${driven.drift} against ${plain.drift}", driven.drift > plain.drift * 1.3f)
            val (restPlain, restDriven) = plain.radius(0) to driven.radius(0)
            val (glowPlain, glowDriven) = plain.glowStrength() to driven.glowStrength()
            plain.shaped(0.08f, bass = 1f)
            driven.shaped(0.08f, drive = 1f, bass = 1f)
            assertTrue("a kick swells its patch more: ${driven.radius(0) - restDriven} against ${plain.radius(0) - restPlain}",
                driven.radius(0) - restDriven > (plain.radius(0) - restPlain) * 1.2f)
            assertTrue("pushes more", driven.push() - 1f > (plain.push() - 1f) * 1.2f)
            assertTrue("lights more", (driven.color(0) shr 16 and 0xff) > (plain.color(0) shr 16 and 0xff))
            assertTrue("and the glow answers more", driven.glowStrength() - glowDriven > (plain.glowStrength() - glowPlain) * 1.2f)

            driven.shaped(4f)
            assertTrue("the drive has gone: ${driven.driven}", driven.driven < 0.01f)
            plain.shaped(4f)
            driven.shaped(0.08f, bass = 1f)
            plain.shaped(0.08f, bass = 1f)
            assertEquals("and a kick is a kick again", plain.push(), driven.push(), 0.002f)
        }
    }

    @Test
    fun `turned right down, the song's shape moves nothing either`() {
        for (ribbons in listOf(false, true)) {
            fun fresh() = (if (ribbons) apart() else motion().apply { turnTo(IntArray(count) { 0xff806040.toInt() }) }).coverAsInThePlayer().apply { strength = 0f }
            val plain = fresh()
            val shaped = fresh()
            // a build-up, the drop, and the part after it, against the same kicks with no word of any of it
            fun both(seconds: Float, bass: Float = 0f, tension: Float = 0f, drop: Float = 0f, drive: Float = 0f) {
                plain.shaped(seconds, bass = bass)
                shaped.shaped(seconds, bass = bass, tension = tension, drop = drop, drive = drive)
                assertEquals("ribbons $ribbons", plain.drift, shaped.drift, 0f)
                for (i in 0 until plain.count) {
                    assertEquals(plain.x(i), shaped.x(i), 0f)
                    assertEquals(plain.y(i), shaped.y(i), 0f)
                    assertEquals(plain.radius(i), shaped.radius(i), 0f)
                    assertEquals(plain.color(i), shaped.color(i))
                }
                for (i in plain.aura.indices) {
                    assertEquals(plain.auraRadius(i), shaped.auraRadius(i), 0f)
                    assertEquals(plain.auraColor(i), shaped.auraColor(i))
                }
                assertEquals(plain.glowStrength(), shaped.glowStrength(), 0f)
                assertEquals(plain.glowHeight(), shaped.glowHeight(), 0f)
            }
            both(3f, tension = 1f)
            both(0.05f, bass = 1f, drop = 1f, drive = 1f)
            both(0.05f, bass = 1f, drop = 0.6f, drive = 1f)
            both(2f, drive = 1f)
        }
    }

    @Test
    fun `turned up, the song's shape shows more, and stays inside the picture's limits`() {
        fun at(strength: Float) = motion().coverAsInThePlayer().apply { this.strength = strength; turnTo(IntArray(count) { 0xff806040.toInt() }) }
        val (low, middle, high) = Triple(at(0.25f), at(0.5f), at(1f))
        for (m in listOf(low, middle, high)) m.shaped(3f, tension = 1f)
        assertTrue("drawn in more: ${low.push()} ${middle.push()} ${high.push()}", low.push() > middle.push() && middle.push() > high.push())
        assertTrue("never by much: ${high.push()}", high.push() > 0.8f)
        for (m in listOf(low, middle, high)) m.dropped(0.1f)
        assertTrue("pushed out more: ${low.push()} ${middle.push()} ${high.push()}", low.push() < middle.push() && middle.push() <= high.push())
        assertTrue("never by more than so much: ${high.push()}", high.push() <= 1f + LivingField.MOST_PUSH)
        for (i in 0 until high.count) {
            assertTrue("radius ${high.radius(i)}", high.radius(i) <= LivingField.REST_RADIUS * (1.05f + LivingField.MOST_SWELL))
            assertTrue("x ${high.x(i)}", high.x(i) in -0.15f..1.15f)
            assertTrue("y ${high.y(i)}", high.y(i) in -0.15f..1.15f)
        }
        for (i in high.aura.indices) {
            assertTrue(high.auraRadius(i) <= LivingField.AURA_MOST)
            assertTrue(high.auraStrength(i) in 0f..1f)
        }
        assertTrue(high.glowStrength() <= 1f && high.glowHeight() <= 0.8f)
    }

    @Test
    fun `when not much is going on, the song's shape hardly shows`() {
        val motion = motion()
        motion.shaped(4f, tension = 1f, going = 0.15f)
        assertEquals("a build-up in a quiet passage", 0.15f, motion.gathered, 0.02f)
        motion.shaped(4f, drive = 1f, going = 0.15f)
        assertEquals(0.15f, motion.driven, 0.02f)
        val quiet = motion().apply { dropped(0.1f, going = 0.15f) }
        val loud = motion().apply { dropped(0.1f) }
        assertTrue("a drop there is no flash: ${quiet.burst} against ${loud.burst}", quiet.burst < loud.burst * 0.2f)
        motion.shaped(1f, tension = 1f, drop = 1f, drive = 1f, going = 0f)
        assertTrue("nothing going on, nothing of it", motion.gathered < 0.01f && motion.burst < 0.01f)
    }

    @Test
    fun `levels that say nothing of the song's shape move the picture as they always did`() {
        val motion = motion()
        repeat(120) { motion.step(frame, floatArrayOf(1f, 0.5f, 0.5f), true) }
        repeat(120) { motion.step(frame, floatArrayOf(1f, 0.5f, 0.5f, 1f), true) }
        repeat(30) { motion.step(frame, floatArrayOf(1f, 0.5f, 0.5f, 1f, Float.NaN, Float.NaN, Float.NaN), true) }
        assertEquals(0f, motion.gathered + motion.burst + motion.driven, 0f)
        motion.step(frame, floatArrayOf(0f, 0f, 0f, 1f, 9f, -2f, 9f), true)
        assertTrue("and what is out of range is held to it", motion.gathered in 0f..1f && motion.burst == 0f && motion.driven in 0f..1f)
    }

    @Test
    fun `with the music stopped the song's shape lets go too, and the picture comes to rest`() {
        val motion = motion()
        motion.shaped(3f, tension = 1f)
        motion.dropped(0.2f)
        assertFalse(motion.atRest())
        motion.run(8f, playing = false, measured = false)
        assertTrue("gathered ${motion.gathered}, burst ${motion.burst}, driven ${motion.driven}", motion.atRest())
        motion.shaped(1f, tension = 1f, drive = 1f)
        motion.settle()
        assertEquals("told to be still, it is", 0f, motion.gathered + motion.burst + motion.driven, 0f)
        assertEquals(1f, motion.push(), 0f)
    }

    // Coming back on screen

    @Test
    fun `back on screen it is in the colours of the song that plays, not turning into them from an older one's`() {
        val motion = motion()
        motion.turnTo(IntArray(motion.count) { red })
        motion.run(1f)
        // closed to the mini player: two more songs go by, and nothing steps
        motion.turnTo(IntArray(motion.count) { blue })
        motion.turnTo(IntArray(motion.count) { green })
        assertTrue("still showing the song it left on", motion.patches().all { it == red })
        motion.arrive()
        assertTrue("there at once", motion.patches().all { it == green })
        assertEquals(LivingField.lit(green, LivingField.GLOW_LIGHT), motion.glow)
        motion.run(0.5f)
        assertTrue("and not turning any more", motion.patches().all { it == green })
        // while it is on screen a new cover is still turned into
        motion.turnTo(IntArray(motion.count) { blue })
        motion.run(0.3f)
        assertTrue(motion.colors[0] != green && motion.colors[0] != blue)
    }

    @Test
    fun `the background settles its colours when its frames start again`() {
        val source = java.io.File("src/main/java/com/dd3boh/outertune/ui/player/LivingBackground.kt").readText()
        val frames = source.substringAfter("repeatOnLifecycle(Lifecycle.State.STARTED) {").substringBefore("withFrameNanos")
        assertTrue("before the first frame of a new run", frames.contains("motion.arrive()"))
        assertTrue("told that it was off screen by the player closing, or hidden by the queue opening over it", source.substringAfter("if (!onScreen || covered) {").substringBefore("}").contains("look.unseen = true"))
        assertTrue("and by the app leaving the screen", source.substringAfter("} finally {").substringBefore("PlayerCoverPlace").contains("look.unseen = true"))
    }

    // How often it is redrawn

    /** The frames of a screen of [hz] over [seconds], as the times they come at, the one that ends the last second with them. */
    private fun frames(hz: Double, seconds: Double = 3.0, from: Long = 1_000_000_000L): LongArray =
        LongArray(Math.round(seconds * hz).toInt() + 1) { from + Math.round(it * 1e9 / hz) }

    /** Which of [frames] the picture is redrawn on, by their place in the row. */
    private fun drawnOf(frames: LongArray, pace: RedrawPace = RedrawPace()): List<Int> =
        frames.indices.filter { pace.due(frames[it]) }

    /** How many redraws a screen of [hz] gets in its third second, with every [missEvery]th frame missed if that is not 0. */
    private fun redraws(hz: Double, missEvery: Int = 0, pace: RedrawPace = RedrawPace(), from: Long = 1_000_000_000L): Int {
        var count = 0
        for (n in 0 until (3 * hz).toInt()) {
            if (missEvery > 0 && n % missEvery == missEvery - 1) continue
            if (pace.due(from + Math.round(n * 1e9 / hz)) && n >= 2 * hz) count++
        }
        return count
    }

    @Test
    fun `it is redrawn thirty times a second at most, whatever the screen can do`() {
        assertEquals(30, RedrawPace.MOST_A_SECOND)
        assertEquals("every second frame at 60 Hz", 30, redraws(60.0))
        assertEquals("every third at 90 Hz, where it was every one", 30, redraws(90.0))
        assertEquals("every fourth at 120 Hz", 30, redraws(120.0))
        assertEquals(30, redraws(180.0))
        assertEquals(30, redraws(240.0))
        assertEquals("a slow screen gets what it has", 30, redraws(30.0))
        assertEquals(24, redraws(24.0))
        // where thirty does not go into the screen's number, the most it has under thirty
        assertEquals("every fifth at 144 Hz", 29, redraws(144.0))
        assertEquals("every sixth at 165 Hz", 28, redraws(165.0))
        assertEquals("every third at 75 Hz", 25, redraws(75.0))
        assertEquals(25, redraws(50.0))
        assertEquals("a screen a hair slow of its number is still that screen", 30, redraws(59.94))
        assertEquals(30, redraws(119.88))

        assertEquals("from the first frame on", List(31) { it * 3 }, drawnOf(frames(90.0, 1.0)))
        assertEquals(List(31) { it * 2 }, drawnOf(frames(60.0, 1.0)))
        assertEquals(List(31) { it * 4 }, drawnOf(frames(120.0, 1.0)))
    }

    @Test
    fun `no two redraws are closer than a thirtieth of a second less a hair, on any screen`() {
        assertEquals(31_333_333L, RedrawPace.APART_NANOS)
        // every screen from 24 Hz to 240 Hz and the ones a little off their number, each with a frame missed now and then
        val screens = (24..240).map { it.toDouble() } + listOf(59.94, 60.3, 61.5, 89.91, 90.4, 119.88, 143.86)
        for (hz in screens) for (missEvery in listOf(0, 7)) {
            val times = frames(hz, 4.0).filterIndexed { n, _ -> missEvery == 0 || n % missEvery != missEvery - 1 }.toLongArray()
            val shown = drawnOf(times).map { times[it] }
            val closest = shown.zipWithNext { a, b -> b - a }.min()
            assertTrue("$hz Hz, a frame missed every $missEvery: two redraws ${closest / 1e6} ms apart", closest >= RedrawPace.APART_NANOS)
            // which is at most thirty-two in any second, and that only on a screen that runs fast of its number
            assertTrue("$hz Hz: ${shown.size} redraws in four seconds", shown.size <= 4 * 32)
        }
    }

    @Test
    fun `a frame that comes a hair early or late is still the frame`() {
        // a 90 Hz screen whose frames come up to 0.6 ms off their time, now early, now late
        val times = frames(90.0, 2.0).also { for (n in it.indices) it[n] += ((n * 37 % 13) - 6) * 100_000L }
        assertEquals(List(61) { it * 3 }, drawnOf(times))
    }

    @Test
    fun `a missed frame is made up on the one after, and a screen that changes its speed is followed at once`() {
        // 90 Hz, and the frame the fourth redraw was due on never comes
        val times = frames(90.0, 1.0).filterIndexed { n, _ -> n != 9 }.toLongArray()
        assertEquals("the one after it stands in, and the pace goes on from there",
            listOf(0L, 3L, 6L, 10L, 13L, 16L), drawnOf(times).take(6).map { Math.round((times[it] - times[0]) * 90 / 1e9) })
        assertEquals("60 Hz with every tenth frame missed, none of them one it is drawn on", 30, redraws(60.0, missEvery = 10))
        assertEquals("90 Hz with every tenth missed: each costs the one frame it waits", 27, redraws(90.0, missEvery = 10))
        val pace = RedrawPace()
        redraws(120.0, pace = pace)
        assertEquals("three seconds at 120 Hz, then 60", 30, redraws(60.0, pace = pace, from = 4_000_000_000L))
        assertEquals("and back", 30, redraws(120.0, pace = pace, from = 7_000_000_000L))
    }

    @Test
    fun `two pictures that share a pace are redrawn on the same frames`() {
        val pace = RedrawPace()
        val one = ArrayList<Int>()
        val other = ArrayList<Int>()
        val times = frames(90.0, 1.0)
        for (n in times.indices) {
            // both are asked about every frame, one after the other
            if (pace.due(times[n])) one += n
            if (pace.due(times[n])) other += n
        }
        assertEquals(List(31) { it * 3 }, one)
        assertEquals("asked again about a frame, it says what it said", one, other)
    }

    // Moving by the clock

    /**
     * Music made up for these tests, as the levels at a moment: a kick every half second that
     * fades over a sixth of one, a voice that comes and goes, and cymbals eight times a second,
     * in frames of 20 ms as the analyser gives them.
     */
    private fun music(nanos: Long): FloatArray {
        val ms = Math.floorDiv(nanos, 20_000_000L) * 20
        val sinceKick = Math.floorMod(ms, 500L)
        val bass = if (sinceKick < 160) 1f - sinceKick / 160f else 0.05f
        val voice = (0.5 + 0.4 * kotlin.math.sin(2 * Math.PI * ms / 3100.0)).toFloat()
        val top = if (Math.floorMod(ms, 125L) < 20) 0.9f else 0.1f
        return floatArrayOf(bass, voice, top)
    }

    private val heard = LivingMotion.Heard { music(it) }

    /** A picture with a cover standing in it as in the player: of the cover, or in ribbons. */
    private fun pictured(ribbons: Boolean) =
        (if (ribbons) apart() else motion().apply { turnTo(IntArray(count) { 0xff806040.toInt() }) }).coverAsInThePlayer()

    @Test
    fun `where the picture is at a moment does not depend on how often it is drawn`() {
        val start = 7_000_000_000L
        val four = 4.0
        // frames that come as they please, a few milliseconds apart or most of a tenth of a second, and the last on the dot
        val stutter = ArrayList<Long>().apply {
            var at = start
            var n = 0
            while (at < start + 4_000_000_000L) {
                add(at)
                at += listOf(5L, 37L, 11L, 83L, 23L, 61L, 9L, 48L)[n++ % 8] * 1_000_000L
            }
            add(start + 4_000_000_000L)
        }.toLongArray()
        for (ribbons in listOf(false, true)) {
            fun moved(times: LongArray, pace: RedrawPace? = null) = pictured(ribbons).apply {
                for (now in times) if (pace == null) moveTo(now, true, heard) else frame(now, pace, true, heard)
            }
            // moved on at every frame of a 120 Hz screen, which is one step a frame
            val every = moved(frames(120.0, four, start))
            assertTrue("it has moved: ${every.drift}", every.drift > 2f)
            val others = linkedMapOf(
                "moved on at every frame of a 30 Hz screen" to moved(frames(30.0, four, start)),
                "of a 60 Hz one" to moved(frames(60.0, four, start)),
                "of a 90 Hz one" to moved(frames(90.0, four, start)),
                "of a 144 Hz one" to moved(frames(144.0, four, start)),
                "redrawn thirty times a second on a 60 Hz screen" to moved(frames(60.0, four, start), RedrawPace()),
                "on a 90 Hz one" to moved(frames(90.0, four, start), RedrawPace()),
                "on a 120 Hz one" to moved(frames(120.0, four, start), RedrawPace()),
                "on frames that come as they please" to moved(stutter),
            )
            for ((how, other) in others) {
                val said = "$how, ribbons $ribbons"
                assertArrayEquals(said, every.shown, other.shown, 0f)
                assertEquals(said, every.drift, other.drift, 0f)
                assertEquals(said, every.pace, other.pace, 0f)
                assertArrayEquals(said, every.auraShown, other.auraShown, 0f)
                assertEquals(said, every.glowHeight(), other.glowHeight(), 0f)
                assertEquals(said, every.glowStrength(), other.glowStrength(), 0f)
                for (i in 0 until every.count) {
                    assertEquals("$said, patch $i", every.x(i), other.x(i), 0f)
                    assertEquals("$said, patch $i", every.y(i), other.y(i), 0f)
                    assertEquals("$said, patch $i", every.radius(i), other.radius(i), 0f)
                    assertEquals("$said, patch $i", every.color(i), other.color(i))
                }
                for (i in every.aura.indices) {
                    assertEquals("$said, aura $i", every.auraRadius(i), other.auraRadius(i), 0f)
                    assertEquals("$said, aura $i", every.auraColor(i), other.auraColor(i))
                }
            }
        }
    }

    @Test
    fun `drawn thirty times a second it moves as it did when it took a step for every frame`() {
        val start = 7_000_000_000L
        // The music is read 63 ms ahead, as the picture reads it. That also keeps the analyser's
        // frames, which here begin on round numbers, from changing on the very nanosecond a step ends.
        val ahead = 63_000_000L
        val aheadHeard = LivingMotion.Heard { music(it + ahead) }
        // how far apart the two may be on each screen: as far along, the kick and the voice at the same instant, the cymbals
        val within = mapOf(60.0 to Triple(0.01f, 0.03f, 0.15f), 90.0 to Triple(0.003f, 0.02f, 0.15f), 120.0 to Triple(0.0001f, 0.001f, 0.001f))
        for ((hz, near) in within) for (ribbons in listOf(false, true)) {
            val before = pictured(ribbons)
            val now30 = pictured(ribbons)
            val pace = RedrawPace()
            var last = 0L
            var redrawn = 0
            var worst = 0f
            var worstTop = 0f
            val peakBefore = FloatArray(3)
            val peakDrawn = FloatArray(3)
            for (now in frames(hz, 20.0, start)) {
                // as it was: one step for every frame of the screen, as long as the frame
                before.step(if (last == 0L) 0f else (now - last) / 1e9f, music(now + ahead), true)
                last = now
                // the highest each range gets, once the picture has warmed up
                if (now > start + 2_000_000_000L) for (b in 0..2) peakBefore[b] = maxOf(peakBefore[b], before.shown[b])
                if (!now30.frame(now, pace, true, aheadHeard)) continue
                if (now > start + 2_000_000_000L) for (b in 0..2) peakDrawn[b] = maxOf(peakDrawn[b], now30.shown[b])
                redrawn++
                worst = maxOf(worst, abs(before.shown[MusicLevels.BASS] - now30.shown[MusicLevels.BASS]), abs(before.shown[MusicLevels.MID] - now30.shown[MusicLevels.MID]))
                worstTop = maxOf(worstTop, abs(before.shown[MusicLevels.HIGH] - now30.shown[MusicLevels.HIGH]))
            }
            val said = "$hz Hz, ribbons $ribbons"
            assertEquals(said, 601, redrawn)
            assertEquals("$said: as far along after twenty seconds", before.drift, now30.drift, before.drift * near.first)
            assertTrue("$said: the kick and the voice as high at every redraw, $worst apart at worst", worst < near.second)
            // a cymbal is over in a frame of the analyser's, and where a step falls in it was always the screen's doing
            assertTrue("$said: the cymbals $worstTop apart at worst", worstTop < near.third)
            // What a third of the frames costs: a hit is caught a little off its top. The kick's
            // highest redraw is within 3% of the highest frame it used to have, a cymbal's within 22%.
            val kick = peakDrawn[MusicLevels.BASS] / peakBefore[MusicLevels.BASS]
            val cymbal = peakDrawn[MusicLevels.HIGH] / peakBefore[MusicLevels.HIGH]
            assertTrue("$said: the kick at its highest redraw, $kick of what it was", kick > 0.97f && kick <= 1.001f)
            assertTrue("$said: a cymbal at its highest redraw, $cymbal of what it was", cymbal > 0.78f && cymbal <= 1.001f)
        }
    }

    @Test
    fun `on the frames between two redraws nothing of it is touched`() {
        val motion = pictured(true)
        val pace = RedrawPace()
        var asked = 0
        val counted = LivingMotion.Heard { asked++; music(it) }
        var redrawn = 0
        for (now in frames(90.0, 2.0)) {
            val drift = motion.drift
            val shown = motion.shown.copyOf()
            val askedBefore = asked
            if (motion.frame(now, pace, true, counted)) {
                redrawn++
            } else {
                assertEquals(drift, motion.drift, 0f)
                assertArrayEquals(shown, motion.shown, 0f)
                assertEquals("and the music is not asked about", askedBefore, asked)
            }
        }
        assertEquals("every third frame of two seconds", 61, redrawn)
        assertEquals("four steps to a redraw, each told what is heard as it ends", 240, asked)
        assertEquals(120, LivingMotion.STEPS_A_SECOND)
    }

    @Test
    fun `the first frame only starts the clock, and a long gap between two frames is not a leap`() {
        val loud = LivingMotion.Heard { floatArrayOf(1f, 1f, 1f) }
        val at = 3_000_000_000L
        val first = motion().apply { moveTo(at, true, loud) }
        assertEquals(0f, first.drift, 0f)
        assertTrue(first.shown.all { it == 0f })
        val tenth = motion().apply { moveTo(at, true, loud); moveTo(at + 100_000_000L, true, loud) }
        val age = motion().apply { moveTo(at, true, loud); moveTo(at + 30_000_000_000L, true, loud) }
        assertTrue("a tenth of a second on: ${tenth.shown[MusicLevels.BASS]}", tenth.shown[MusicLevels.BASS] > 0.9f && tenth.drift > 0f)
        assertEquals("and no further after half a minute", tenth.drift, age.drift, 0f)
        assertArrayEquals(tenth.shown, age.shown, 0f)
        // it goes on from there at its own pace
        val on = motion().apply { moveTo(at, true, loud); moveTo(at + 30_000_000_000L, true, loud); moveTo(at + 30_033_333_333L, true, loud) }
        val twin = motion().apply { moveTo(at, true, loud); moveTo(at + 100_000_000L, true, loud); moveTo(at + 133_333_333L, true, loud) }
        assertEquals(twin.drift, on.drift, 0f)
        // a frame asked about twice moves it once, and with nothing to go by it drifts without breathing
        val twice = motion().apply { moveTo(at, true, loud); moveTo(at + 100_000_000L, true, loud); moveTo(at + 100_000_000L, true, loud) }
        assertEquals(tenth.drift, twice.drift, 0f)
        val deaf = motion().apply { moveTo(at, true); moveTo(at + 100_000_000L, true) }
        assertTrue(deaf.drift > 0f && deaf.shown.all { it == 0f })
    }

    @Test
    fun `the music stopped, it comes to rest when it did, and from then on nothing is to move`() {
        val start = 7_000_000_000L
        val times = frames(90.0, 12.0, start)
        val stops = start + 3_000_000_000L
        // as it was: a step for every frame of a 90 Hz screen
        val before = pictured(true)
        var last = 0L
        var restedBefore = 0L
        for (now in times) {
            before.step(if (last == 0L) 0f else (now - last) / 1e9f, if (now < stops) music(now) else null, now < stops)
            last = now
            if (now >= stops && before.atRest()) { restedBefore = now; break }
        }
        val now30 = pictured(true)
        val pace = RedrawPace()
        val silent = LivingMotion.Heard { if (it < stops) music(it) else null }
        var rested = 0L
        var redrawnAfter = 0
        for (now in times) {
            if (now30.frame(now, pace, now < stops, silent) && now >= stops) redrawnAfter++
            if (now >= stops && now30.atRest()) { rested = now; break }
        }
        assertTrue("it used to take ${(restedBefore - stops) / 1e9} s", restedBefore - stops in 2_500_000_000L..4_500_000_000L)
        assertTrue("and takes ${(rested - stops) / 1e9} s, the same to within two redraws", abs(rested - restedBefore) <= 70_000_000L)
        assertTrue("redrawn $redrawnAfter times on the way, a third of the frames", redrawnAfter in 80..140)
    }

    @Test
    fun `the background moves and redraws on the frames the pace gives it and on no others`() {
        val source = java.io.File("src/main/java/com/dd3boh/outertune/ui/player/LivingBackground.kt").readText()
        val onFrame = source.substringAfter("withFrameNanos { now ->").substringBefore("}")
        assertTrue(onFrame, onFrame.contains("if (motion.frame(now, redraws, playing, heard)) frame = now"))
        assertFalse("no step and no redraw of its own beside that", onFrame.contains("motion.step(") || onFrame.contains("motion.moveTo(") || onFrame.contains("frame++"))
        assertTrue("one pace for every picture in the app", source.contains("\nprivate val redraws = RedrawPace()"))
    }

    @Test
    fun `under the open queue the background asks for no frames and goes on listening`() {
        val source = java.io.File("src/main/java/com/dd3boh/outertune/ui/player/LivingBackground.kt").readText()
        val frames = source.substringAfter("LaunchedEffect(onScreen, covered, playing, covers, coverThere, motion, lifecycleOwner, still) {").substringBefore("repeatOnLifecycle")
        assertTrue("it leaves before a frame is asked for", frames.contains("if (!onScreen || covered) {") && frames.contains("return@LaunchedEffect"))
        val watching = source.substringAfter("LaunchedEffect(tap, onScreen, still, lifecycleOwner) {").substringBefore("repeatOnLifecycle")
        assertFalse("the watcher does not go with it, or a look at the queue would start the song's shape over", watching.contains("covered"))
        val player = java.io.File("src/main/java/com/dd3boh/outertune/ui/player/Player.kt").readText()
        assertTrue(player.contains("covered = queueHidesBackground(playerExpanded = state.isExpanded, queueSheetExpanded = queueSheetState.isExpanded)"))
    }

    @Test
    fun `a level that is not a number is no level`() {
        val motion = motion()
        motion.step(frame, floatArrayOf(Float.NaN, 7f, -3f), true)
        motion.run(1f, bass = 0.5f)
        assertTrue(motion.shown.all { it in 0f..1f })
        assertTrue((0 until motion.count).all { motion.radius(it).isFinite() && motion.x(it).isFinite() })
    }

    @Test
    fun `a long gap between two frames is not a leap`() {
        val one = motion().apply { step(0.1f, floatArrayOf(1f, 1f, 1f), true) }
        val other = motion().apply { step(30f, floatArrayOf(1f, 1f, 1f), true) }
        assertEquals(one.drift, other.drift, 0f)
        assertArrayEquals(one.shown, other.shown, 0f)
    }
}
