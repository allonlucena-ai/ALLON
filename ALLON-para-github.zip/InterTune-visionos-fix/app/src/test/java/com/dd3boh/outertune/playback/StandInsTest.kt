/*
 * Copyright (C) 2026 InterTune
 *
 * SPDX-License-Identifier: GPL-3.0
 */

package com.dd3boh.outertune.playback

import androidx.media3.common.PlaybackException
import com.dd3boh.outertune.playback.StandInMemory.Entry
import com.dd3boh.outertune.playback.StandInMemory.Memory
import com.dd3boh.outertune.utils.YTPlayerUtils
import com.zionhuang.innertube.models.Artist
import com.zionhuang.innertube.models.SongItem
import com.zionhuang.innertube.models.response.PlayerResponse
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.IOException

/**
 * A song whose own id YouTube calls gone is looked for under another, played from there, and the
 * swap remembered. Everything else about asking for a stream stays as it was: a song that plays
 * costs one request and no search, and one that fails for any other reason fails the same way.
 */
class StandInsTest {
    private val t0 = 1_791_000_000_000L
    private val day = 24L * 60 * 60 * 1000
    private var now = t0
    private val stored = mutableListOf<String>()
    private val gone = mutableListOf<String>()
    private val plays = mutableListOf<String>()
    private val reported = mutableListOf<String>()

    /** The songs reported gone on the account's word too, and the runs not believed, as they were handed over. */
    private val sure = mutableListOf<String>()
    private val doubted = mutableListOf<List<String>>()

    @Before
    fun fresh() {
        StandInMemory.current = Memory()
        StandInMemory.onChanged = { stored += it }
    }

    @After
    fun leaveNothingBehind() {
        StandInMemory.current = Memory()
        StandInMemory.onChanged = null
    }

    private fun stream(of: String) = YTPlayerUtils.PlaybackData(
        audioConfig = null,
        videoDetails = null,
        playbackTracking = null,
        format = PlayerResponse.StreamingData.Format(
            itag = 251, url = "https://$of.example/videoplayback", mimeType = "audio/webm; codecs=\"opus\"",
            bitrate = 140_000, width = null, height = null, contentLength = 3_000_000, quality = "tiny", fps = null,
            qualityLabel = null, averageBitrate = null, audioQuality = null, approxDurationMs = null,
            audioSampleRate = 48_000, audioChannels = 2, loudnessDb = null, lastModified = null, signatureCipher = null,
        ),
        streamUrl = "https://$of.example/videoplayback",
        streamExpiresInSeconds = 21_540,
    )

    private fun result(id: String, title: String = "Instant Crush", seconds: Int? = 337, artist: String = "Daft Punk") =
        SongItem(id = id, title = title, artists = listOf(Artist(name = artist, id = null)), album = null, duration = seconds, thumbnail = "", explicit = false)

    private val unavailable get() = YTPlayerUtils.SongUnavailable("This video is not available")
    private val isGone: () -> Result<YTPlayerUtils.PlaybackData> = { Result.failure(unavailable) }
    private fun serves(id: String): () -> Result<YTPlayerUtils.PlaybackData> = { Result.success(stream(id)) }

    /**
     * What YouTube says of each id, what a search finds for each song, and everything that was
     * asked. One instance, so one run, as the player has.
     */
    private inner class World(
        private val says: Map<String, () -> Result<YTPlayerUtils.PlaybackData>>,
        private val finds: Map<String, () -> List<SongItem>> = emptyMap(),
        private val knows: Boolean = true,
        on: Boolean = true,
        /** The songs the database says are set aside as gone: see StandIns' setAside. */
        setAside: Set<String> = emptySet(),
    ) {
        val asked = mutableListOf<String>()

        /** The ids walked as another copy of the song than its own: see YTPlayerUtils.OfAnotherCopy. */
        val walkedAsACopy = mutableListOf<String>()
        private var lookedFor = ""
        private var walked: String? = null
        val standIns = StandIns(
            resolve = { id ->
                asked += "stream $id"
                if (currentCoroutineContext()[YTPlayerUtils.OfAnotherCopy] != null) walkedAsACopy += id
                (says[id] ?: error("$id was not expected to be asked")).invoke().also { walked = if (it.isSuccess) "OK" else "ERROR" }
            },
            wanted = { id ->
                asked += "song $id"
                lookedFor = id
                if (knows) StandIn.Wanted("Instant Crush", listOf("Daft Punk"), 337) else null
            },
            search = { query ->
                asked += "search $query"
                (finds[lookedFor] ?: finds["*"] ?: error("no search was expected for $lookedFor")).invoke()
            },
            now = { now },
            log = {},
            enabled = { on },
            trail = { walked },
            report = { reported += it },
            setAside = { id -> id in setAside },
        ).also {
            it.onGone = { id, onTheAccountsWord ->
                gone += id
                if (onTheAccountsWord) sure += id
            }
            it.onPlays = { id -> plays += id }
            it.onDoubted = { ids -> doubted += ids }
        }

        fun play(id: String = "OLDID000001") = runBlocking { standIns.playbackData(id) }

        /** The song asked for again by the listener, as the player's Retry or Play on a song it stopped on. */
        fun playAgainByHand(id: String = "OLDID000001") = runBlocking { standIns.playbackData(id, askedAgain = true) }
    }

    private fun nothingFound(vararg ids: String) = World(says = ids.associateWith { isGone }, finds = mapOf("*" to { emptyList() }))

    @Test
    fun `a song that plays under its own id is asked for once, and nothing is searched`() {
        val world = World(mapOf("OLDID000001" to serves("OLDID000001")))

        val played = world.play().getOrThrow()

        assertEquals("https://OLDID000001.example/videoplayback", played.data.streamUrl)
        assertEquals("OLDID000001", played.from)
        assertEquals(listOf("stream OLDID000001"), world.asked)
        assertEquals(listOf("OLDID000001"), plays)
        assertEquals(emptyList<String>(), stored)
    }

    @Test
    fun `a song that fails for any other reason fails as it did, and nothing is searched`() {
        for (failure in listOf(IOException("no network"), PlaybackException("YouTube refused the stream (HTTP 403)", null, PlaybackException.ERROR_CODE_REMOTE_ERROR))) {
            val world = World(mapOf("OLDID000001" to { Result.failure(failure) }))

            assertSame(failure, world.play().exceptionOrNull())
            assertEquals(listOf("stream OLDID000001"), world.asked)
        }
        assertEquals(emptyList<String>(), gone)
        assertEquals(emptyList<String>(), stored)
    }

    @Test
    fun `with the switch off a song that is gone fails as it always has`() {
        StandInMemory.current = StandInMemory.remember(Memory(), "OLDID000001", "NEWID000001", t0 - 1_000)
        val failure = unavailable
        val world = World(mapOf("OLDID000001" to { Result.failure(failure) }), on = false)

        assertSame(failure, world.play().exceptionOrNull())
        // Not even what is remembered is used: nothing but the song's own id is ever asked.
        assertEquals(listOf("stream OLDID000001"), world.asked)
        assertEquals(emptyList<String>(), gone)
        assertEquals(emptyList<String>(), plays)
        assertEquals(emptyList<String>(), stored)
    }

    @Test
    fun `a song that is gone is played from the same recording under another id, and the swap is kept`() {
        val world = World(
            says = mapOf("OLDID000001" to isGone, "NEWID000001" to serves("NEWID000001")),
            finds = mapOf("*" to { listOf(result("OTHER000001", title = "Instant Crush (Live)"), result("NEWID000001")) }),
        )

        val played = world.play().getOrThrow()

        assertEquals("https://NEWID000001.example/videoplayback", played.data.streamUrl)
        assertEquals("the resolver has to know it is another upload's", "NEWID000001", played.from)
        assertEquals(listOf("stream OLDID000001", "song OLDID000001", "search Instant Crush Daft Punk", "stream NEWID000001"), world.asked)
        assertEquals("NEWID000001", StandInMemory.idFor("OLDID000001", now))
        assertEquals(listOf("OLDID000001=NEWID000001@$t0"), stored)
        assertEquals(emptyList<String>(), gone)
        assertEquals(listOf("OLDID000001"), plays)

        // The next time it is one request, as for any song.
        world.asked.clear()
        now += 60_000
        assertEquals("NEWID000001", world.play().getOrThrow().from)
        assertEquals(listOf("stream NEWID000001"), world.asked)
        assertEquals(listOf("OLDID000001", "OLDID000001"), plays)
    }

    @Test
    fun `a song that is gone and has no other copy fails with YouTube's words, and that is noted`() {
        val failure = unavailable
        val world = World(
            says = mapOf("OLDID000001" to { Result.failure(failure) }),
            finds = mapOf("*" to { listOf(result("OTHER000001", title = "Instant Crush (Slowed)"), result("OTHER000002", artist = "Karaoke Hits")) }),
        )

        assertSame(failure, world.play().exceptionOrNull())
        assertEquals(listOf("OLDID000001"), gone)
        assertEquals(listOf("OLDID000001=@$t0"), stored)
        assertEquals("OLDID000001", StandInMemory.idFor("OLDID000001", now))
    }

    @Test
    fun `a song looked for in vain is not searched for again for three days, and costs what it always did`() {
        val world = World(
            says = mapOf("OLDID000001" to isGone, "FINE0000001" to serves("FINE0000001")),
            finds = mapOf("*" to { emptyList() }),
        )
        world.play()
        world.play("FINE0000001")
        world.asked.clear()

        now += 2 * day
        world.play()
        assertEquals("one request, as before any of this", listOf("stream OLDID000001"), world.asked)
        assertEquals("and it is still reported, each time", listOf("OLDID000001", "OLDID000001"), gone)

        world.play("FINE0000001")
        world.asked.clear()
        now += 2 * day
        world.play()
        assertEquals(listOf("stream OLDID000001", "song OLDID000001", "search Instant Crush Daft Punk"), world.asked)
    }

    @Test
    fun `a search that fails says nothing of the song, and none is made for a while after`() {
        val failure = unavailable
        val world = World(
            says = mapOf("OLDID000001" to { Result.failure(failure) }, "OLDID000002" to isGone),
            finds = mapOf("*" to { throw IOException("no network") }),
        )

        assertSame(failure, world.play().exceptionOrNull())
        assertEquals(emptyList<String>(), gone)
        assertEquals(emptyList<String>(), stored)

        world.asked.clear()
        now += 60_000
        world.play("OLDID000002")
        assertEquals("the next song does not wait on a search that is failing", listOf("stream OLDID000002"), world.asked)

        world.asked.clear()
        now += StandIn.SEARCH_REST_MS
        world.play("OLDID000002")
        assertEquals(listOf("stream OLDID000002", "song OLDID000002", "search Instant Crush Daft Punk"), world.asked)
    }

    @Test
    fun `a search that does not answer in time says nothing of the song either`() {
        val failure = unavailable
        val standIns = StandIns(
            resolve = { Result.failure(failure) },
            wanted = { StandIn.Wanted("Instant Crush", listOf("Daft Punk"), 337) },
            search = { delay(60_000); listOf(result("NEWID000001")) },
            now = { now },
            log = {},
            searchLimitMs = 50,
            enabled = { true },
            trail = { "VISIONOS ERROR" },
            report = { reported += it },
        ).also { it.onGone = { id, _ -> gone += id } }

        assertSame(failure, runBlocking { standIns.playbackData("OLDID000001") }.exceptionOrNull())
        assertEquals(emptyList<String>(), gone)
        assertEquals(emptyList<String>(), stored)
        assertEquals(listOf("own id: VISIONOS ERROR | search did not answer in 50 ms"), reported)
    }

    @Test
    fun `a stand-in that does not play is not kept, and the song is not called gone for it`() {
        val failure = unavailable
        val world = World(
            says = mapOf("OLDID000001" to { Result.failure(failure) }, "NEWID000001" to { Result.failure(IOException("reset")) }),
            finds = mapOf("*" to { listOf(result("NEWID000001")) }),
        )

        assertSame(failure, world.play().exceptionOrNull())
        assertEquals(emptyList<String>(), gone)
        assertEquals(emptyList<String>(), stored)
    }

    @Test
    fun `a song the app knows nothing of is not searched for`() {
        val failure = unavailable
        val world = World(says = mapOf("OLDID000001" to { Result.failure(failure) }), knows = false)

        assertSame(failure, world.play().exceptionOrNull())
        assertEquals(listOf("stream OLDID000001", "song OLDID000001"), world.asked)
        assertEquals(emptyList<String>(), gone)
    }

    @Test
    fun `a stand-in that is gone in its turn gives way to the next copy that plays`() {
        StandInMemory.current = StandInMemory.remember(Memory(), "OLDID000001", "NEWID000001", t0 - 1_000)
        val world = World(
            says = mapOf("NEWID000001" to isGone, "OLDID000001" to isGone, "NEWID000002" to serves("NEWID000002")),
            // The stand-in that just died still comes first in a search. It is not asked again.
            finds = mapOf("*" to { listOf(result("NEWID000001"), result("NEWID000002")) }),
        )

        val played = world.play().getOrThrow()

        assertEquals("NEWID000002", played.from)
        assertEquals(
            listOf("stream NEWID000001", "stream OLDID000001", "song OLDID000001", "search Instant Crush Daft Punk", "stream NEWID000002"),
            world.asked,
        )
        assertEquals("NEWID000002", StandInMemory.idFor("OLDID000001", now))
        assertEquals(listOf("OLDID000001=NEWID000002@$t0"), stored)
    }

    @Test
    fun `when the likeliest copy is gone as well the next is tried, three at most, and then the song is gone`() {
        val failure = unavailable
        val world = World(
            says = mapOf(
                "OLDID000001" to { Result.failure(failure) },
                "NEWID000001" to isGone, "NEWID000002" to isGone, "NEWID000003" to isGone,
            ),
            finds = mapOf("*" to { listOf(result("NEWID000001"), result("NEWID000002"), result("NEWID000003"), result("NEWID000004")) }),
        )

        assertSame(failure, world.play().exceptionOrNull())
        assertEquals(listOf("stream NEWID000001", "stream NEWID000002", "stream NEWID000003"), world.asked.takeLast(3))
        assertEquals(listOf("OLDID000001"), gone)
        assertEquals(listOf("OLDID000001=@$t0"), stored)
    }

    @Test
    fun `a stand-in that fails for another reason is kept, and the song fails as any other would`() {
        StandInMemory.current = StandInMemory.remember(Memory(), "OLDID000001", "NEWID000001", t0 - 1_000)
        val failure = IOException("no network")
        val world = World(mapOf("NEWID000001" to { Result.failure(failure) }))

        assertSame(failure, world.play().exceptionOrNull())
        assertEquals(listOf("stream NEWID000001"), world.asked)
        assertEquals("NEWID000001", StandInMemory.idFor("OLDID000001", now))
        assertEquals(emptyList<String>(), stored)
    }

    @Test
    fun `after a month the song's own id is asked again, and what was kept of it goes if it is back`() {
        StandInMemory.current = StandInMemory.remember(Memory(), "OLDID000001", "NEWID000001", t0 - StandInMemory.KEEP_MS)
        val world = World(mapOf("OLDID000001" to serves("OLDID000001")))

        assertEquals("OLDID000001", world.play().getOrThrow().from)
        assertEquals(listOf("stream OLDID000001"), world.asked)
        assertEquals(Memory(), StandInMemory.current)
    }

    // The error report's "stream chain" is the last walk made. After a lookup that is a copy's,
    // under an error that is the song's own, so the report is given the lookup's walks together.

    @Test
    fun `a song resolved in one walk under its own id leaves the report's chain as the walk wrote it`() {
        World(mapOf("OLDID000001" to serves("OLDID000001"))).play()
        World(mapOf("OLDID000001" to { Result.failure(IOException("no network")) })).play()

        assertEquals(emptyList<String>(), reported)
    }

    @Test
    fun `a lookup tells the report every walk it made, in order, and names no song`() {
        val world = World(
            says = mapOf("OLDID000001" to isGone, "NEWID000001" to isGone, "NEWID000002" to serves("NEWID000002")),
            finds = mapOf("*" to { listOf(result("NEWID000001"), result("NEWID000002")) }),
        )

        world.play()
        assertEquals(listOf("own id: ERROR | copy 1: ERROR | copy 2: OK"), reported)

        // Played from what it remembers, the one walk is the stand-in's, and the report says so.
        reported.clear()
        world.play()
        assertEquals(listOf("stand-in: OK"), reported)
    }

    @Test
    fun `a lookup that plays nothing tells the report why`() {
        val world = World(
            says = mapOf("OLDID000001" to isGone, "FINE0000001" to serves("FINE0000001")),
            finds = mapOf("*" to { listOf(result("OTHER000001", title = "Instant Crush (Live)")) }),
        )

        world.play()
        world.play()
        world.play("FINE0000001")
        world.play()

        assertEquals(
            listOf(
                "own id: ERROR | search: 1 results, none surely the same recording",
                "own id: ERROR | no search: looked for already since a stream last resolved",
                "own id: ERROR | no search: looked for these last days, and nothing was surely it",
            ),
            reported,
        )
    }

    @Test
    fun `a search that fails is in the report, and so is the rest it is given`() {
        val world = World(says = mapOf("OLDID000001" to isGone), finds = mapOf("*" to { throw IOException("no network") }))

        world.play()
        world.play()

        assertEquals(listOf("own id: ERROR | search failed: IOException", "own id: ERROR | no search: one failed a moment ago"), reported)
    }

    // A run of songs called gone, with no stream resolved between them, is therefore not believed.

    @Test
    fun `the third song in a row called gone puts back what the run noted, and the fourth is not looked for`() {
        val world = nothingFound("OLDID000001", "OLDID000002", "OLDID000003", "OLDID000004")

        world.play("OLDID000001")
        world.play("OLDID000002")
        assertEquals(listOf("OLDID000001", "OLDID000002"), gone)
        assertEquals(setOf("OLDID000001", "OLDID000002"), StandInMemory.current.of.keys)

        world.play("OLDID000003")
        assertEquals("the third is not reported", listOf("OLDID000001", "OLDID000002"), gone)
        assertEquals("and nothing is left noted of the three", Memory(), StandInMemory.current)

        world.asked.clear()
        world.play("OLDID000004")
        assertEquals(listOf("stream OLDID000004"), world.asked)
        assertEquals(Memory(), StandInMemory.current)
    }

    @Test
    fun `the song that makes the run too long to believe, and each one after it, fails as the connection turned away`() {
        // Issue #28: every song "This video is not available" on one phone, YouTube's words for a
        // session it has stopped serving as much as for a song it no longer has.
        val world = nothingFound("OLDID000001", "OLDID000002", "OLDID000003", "OLDID000004")

        val first = world.play("OLDID000001").exceptionOrNull()
        val second = world.play("OLDID000002").exceptionOrNull()
        assertTrue("$first, $second", first is YTPlayerUtils.SongUnavailable && second is YTPlayerUtils.SongUnavailable)

        for (failed in listOf(world.play("OLDID000003").exceptionOrNull(), world.play("OLDID000004").exceptionOrNull())) {
            assertTrue(failed.toString(), YTPlayerUtils.isConnectionTurnedAway(failed))
            assertFalse("not a song that is gone, for anything that acts on those", YTPlayerUtils.isUnavailableSong(failed))
        }
        assertEquals("nothing reported of the third or the fourth", listOf("OLDID000001", "OLDID000002"), gone)
    }

    @Test
    fun `a run that is not believed puts back the stand-in a song had`() {
        val had = StandInMemory.remember(Memory(), "OLDID000001", "NEWID000001", t0 - 1_000)
        StandInMemory.current = had
        val world = World(
            says = mapOf("NEWID000001" to isGone, "OLDID000001" to isGone, "OLDID000002" to isGone, "OLDID000003" to isGone),
            finds = mapOf("*" to { emptyList() }),
        )

        world.play("OLDID000001")
        assertEquals("for now it is noted as having no copy", Entry(null, t0), StandInMemory.current.of["OLDID000001"])
        world.play("OLDID000002")
        world.play("OLDID000003")

        assertEquals(had, StandInMemory.current)
    }

    @Test
    fun `a song that plays in between starts the count again`() {
        val world = World(
            says = mapOf("OLDID000001" to isGone, "OLDID000002" to isGone, "FINE0000001" to serves("FINE0000001"), "OLDID000003" to isGone),
            finds = mapOf("*" to { emptyList() }),
        )

        world.play("OLDID000001")
        world.play("OLDID000002")
        world.play("FINE0000001")
        world.play("OLDID000003")

        assertEquals(listOf("OLDID000001", "OLDID000002", "OLDID000003"), gone)
        assertEquals(setOf("OLDID000001", "OLDID000002", "OLDID000003"), StandInMemory.current.of.keys)
    }

    @Test
    fun `a song already looked for is not looked for again until something has played`() {
        val world = nothingFound("OLDID000001")

        world.play("OLDID000001")
        world.asked.clear()
        world.play("OLDID000001")

        // The player asks again at every retry and every press of Play.
        assertEquals(listOf("stream OLDID000001"), world.asked)
        assertEquals(listOf("OLDID000001"), gone)
    }

    @Test
    fun `while nothing of the kind is believed, a remembered stand-in that answers gone is kept`() {
        StandInMemory.current = StandInMemory.remember(Memory(), "OLDID000009", "NEWID000009", t0 - 1_000)
        val failure = unavailable
        val world = World(
            says = mapOf("OLDID000001" to isGone, "OLDID000002" to isGone, "OLDID000003" to isGone, "NEWID000009" to { Result.failure(failure) }),
            finds = mapOf("*" to { emptyList() }),
        )
        world.play("OLDID000001"); world.play("OLDID000002"); world.play("OLDID000003")
        world.asked.clear()

        // Not believed, and so said to be the connection turned away (issue #28), in YouTube's words for the log.
        val failed = world.play("OLDID000009").exceptionOrNull()
        assertTrue(failed.toString(), failed is YTPlayerUtils.ConnectionTurnedAway)
        assertTrue(failed?.message.orEmpty().endsWith(failure.message.orEmpty()))
        assertEquals(listOf("stream NEWID000009"), world.asked)
        assertEquals("NEWID000009", StandInMemory.idFor("OLDID000009", now))
    }

    @Test
    fun `a stand-in that plays ends a run as a song's own id does`() {
        val world = World(
            says = mapOf(
                "OLDID000001" to isGone, "OLDID000002" to isGone, "OLDID000003" to isGone,
                "NEWID000003" to serves("NEWID000003"), "OLDID000004" to isGone,
            ),
            finds = mapOf("OLDID000003" to { listOf(result("NEWID000003")) }, "*" to { emptyList() }),
        )
        world.play("OLDID000001")
        world.play("OLDID000002")
        assertEquals("NEWID000003", world.play("OLDID000003").getOrThrow().from)

        world.play("OLDID000004")

        assertEquals(listOf("OLDID000001", "OLDID000002", "OLDID000004"), gone)
        assertEquals(listOf("OLDID000003"), plays)
    }

    @Test
    fun `downloads have a run of their own`() {
        val downloads = GoneRun()
        val player = GoneRun()
        repeat(GoneRun.LIMIT) { downloads.gone("OLDID00000$it") }

        assertEquals(true, downloads.doubted())
        assertEquals(false, player.doubted())
        assertEquals(true, player.maySearch("OLDID000009"))
    }

    // The same song failing again and again is one song, not a run (issue #28's rule is about songs in a row).

    @Test
    fun `the same song failing again and again is one song of a run, and never taken for the connection turned away`() {
        // His radio song of 21 Oct 2026, tapped 13 times.
        val world = nothingFound("OLDID000001", "OLDID000002")
        for (tap in 1..13) {
            val failed = world.play("OLDID000001").exceptionOrNull()
            assertTrue("tap $tap: $failed", failed is YTPlayerUtils.SongUnavailable)
        }
        // A second song called gone after them is the second of the run, and still believed.
        val other = world.play("OLDID000002").exceptionOrNull()
        assertTrue(other.toString(), other is YTPlayerUtils.SongUnavailable)
        assertEquals(listOf("OLDID000001", "OLDID000002"), gone)
    }

    @Test
    fun `nor when other songs play between the taps`() {
        val world = World(says = mapOf("OLDID000001" to isGone, "FINE0000001" to serves("FINE0000001"), "OLDID000002" to isGone), finds = mapOf("*" to { emptyList() }))
        for (tap in 1..13) {
            assertTrue("tap $tap", world.play("OLDID000001").exceptionOrNull() is YTPlayerUtils.SongUnavailable)
            world.play("FINE0000001")
        }
        world.play("OLDID000001")
        assertTrue(world.play("OLDID000002").exceptionOrNull() is YTPlayerUtils.SongUnavailable)
    }

    // Signed in, the account is asked before a song is called gone (YTPlayerUtils). Gone on its
    // word too and no copy that plays: set aside at once, and not asked again at every tap.

    private val goneForTheAccountToo: () -> Result<YTPlayerUtils.PlaybackData> =
        { Result.failure(YTPlayerUtils.SongUnavailable("This video is not available", byTheAccountToo = true)) }

    @Test
    fun `a song the account calls gone too, with no copy that plays, is reported as sure`() {
        World(says = mapOf("OLDID000001" to goneForTheAccountToo), finds = mapOf("*" to { emptyList() })).play()
        nothingFound("OLDID000002").play("OLDID000002")

        assertEquals(listOf("OLDID000001", "OLDID000002"), gone)
        assertEquals("only the one the account called gone", listOf("OLDID000001"), sure)
    }

    @Test
    fun `a song set aside as gone and looked for in vain lately is not asked again, and fails at once as gone`() {
        StandInMemory.current = StandInMemory.remember(Memory(), "OLDID000001", null, t0 - day)
        val world = World(says = emptyMap(), setAside = setOf("OLDID000001"))

        val failure = world.play().exceptionOrNull()

        assertTrue(failure.toString(), failure is YTPlayerUtils.SongUnavailable)
        assertEquals("nothing asked of YouTube, nothing searched", emptyList<String>(), world.asked)
        assertEquals("nothing reported again", emptyList<String>(), gone)
        assertEquals(listOf("not asked: set aside as gone, and looked for in vain these last days"), reported)
    }

    @Test
    fun `asked for again by hand, a song set aside is asked of YouTube again, where a pass of the queue is not`() {
        StandInMemory.current = StandInMemory.remember(Memory(), "OLDID000001", null, t0 - day)
        val world = World(says = mapOf("OLDID000001" to goneForTheAccountToo), setAside = setOf("OLDID000001"))

        assertTrue(world.play().exceptionOrNull() is YTPlayerUtils.SongUnavailable)
        assertEquals("the queue reaching it asks nothing", emptyList<String>(), world.asked)

        val failure = world.playAgainByHand().exceptionOrNull()
        assertEquals("Retry asks YouTube", listOf("stream OLDID000001"), world.asked)
        assertTrue(failure.toString(), failure is YTPlayerUtils.SongUnavailable)
        assertEquals("still gone, and said so", listOf("OLDID000001"), gone)
    }

    @Test
    fun `a song set aside does not count in a run of songs called gone`() {
        StandInMemory.current = StandInMemory.remember(Memory(), "OLDID000001", null, t0 - day)
        val world = World(says = mapOf("OLDID000002" to isGone, "OLDID000003" to isGone), finds = mapOf("*" to { emptyList() }), setAside = setOf("OLDID000001"))

        repeat(5) { world.play("OLDID000001") }
        world.play("OLDID000002")
        val third = world.play("OLDID000003").exceptionOrNull()

        assertTrue("two songs called gone in a row, not seven: $third", third is YTPlayerUtils.SongUnavailable)
        assertEquals(listOf("OLDID000002", "OLDID000003"), gone)
    }

    @Test
    fun `lifted, or looked for three days ago, a song set aside is asked again`() {
        // Lifted on the Exclusions page: the database no longer says it is set aside.
        StandInMemory.current = StandInMemory.remember(Memory(), "OLDID000001", null, t0 - day)
        val lifted = World(says = mapOf("OLDID000001" to goneForTheAccountToo))
        lifted.play()
        assertEquals(listOf("stream OLDID000001"), lifted.asked)
        assertEquals("set aside again on the account's word", listOf("OLDID000001"), sure)

        // Three days on: one more walk, and one more search.
        StandInMemory.current = StandInMemory.remember(Memory(), "OLDID000001", null, t0 - StandInMemory.NONE_MS)
        val later = World(says = mapOf("OLDID000001" to goneForTheAccountToo), finds = mapOf("*" to { emptyList() }), setAside = setOf("OLDID000001"))
        later.play()
        assertEquals(listOf("stream OLDID000001", "song OLDID000001", "search Instant Crush Daft Punk"), later.asked)
    }

    @Test
    fun `a run that is not believed hands over its songs, so that what was set aside at once is taken back`() {
        val world = World(
            says = mapOf("OLDID000001" to goneForTheAccountToo, "OLDID000002" to goneForTheAccountToo, "OLDID000003" to goneForTheAccountToo),
            finds = mapOf("*" to { emptyList() }),
        )
        world.play("OLDID000001")
        world.play("OLDID000002")
        world.play("OLDID000003")

        assertEquals(listOf("OLDID000001", "OLDID000002"), sure)
        assertEquals(setOf("OLDID000001", "OLDID000002", "OLDID000003"), doubted.single().toSet())
    }

    @Test
    fun `a stand-in and the copies a search finds are walked as other copies, the song's own id never`() {
        StandInMemory.current = StandInMemory.remember(Memory(), "OLDID000001", "NEWID000001", t0 - 1_000)
        val world = World(
            says = mapOf("NEWID000001" to isGone, "OLDID000001" to isGone, "NEWID000002" to serves("NEWID000002")),
            finds = mapOf("*" to { listOf(result("NEWID000001"), result("NEWID000002")) }),
        )

        world.play()

        assertEquals(listOf("stream NEWID000001", "stream OLDID000001", "song OLDID000001", "search Instant Crush Daft Punk", "stream NEWID000002"), world.asked)
        assertEquals(listOf("NEWID000001", "NEWID000002"), world.walkedAsACopy)
    }
}
