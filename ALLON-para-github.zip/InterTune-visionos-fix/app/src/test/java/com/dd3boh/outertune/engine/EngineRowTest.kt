/*
 * Copyright (C) 2026 InterTune
 *
 * SPDX-License-Identifier: GPL-3.0
 */

package com.dd3boh.outertune.engine

import com.dd3boh.outertune.constants.EndReason
import com.dd3boh.outertune.constants.PlayOrigin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

/**
 * The row's rules, on a made-up library: whatever the log says, the row never breaks them. These
 * run on every build with no data of anyone's.
 */
class EngineRowTest {
    private val now = 1_789_135_200_000L
    private val hour = 3_600_000L
    private val day = 86_400_000L

    /** A library of [artists] artists with [perArtist] songs each, every song related to every other song of the next artist. */
    private class World(val now: Long) {
        val songs = LinkedHashMap<String, SongRow>()
        val listens = ArrayList<ListenRow>()
        val edges = ArrayList<Edge>()
        var session = 1L
        fun song(id: String, artist: String, title: String = id, liked: Boolean = false, likedAt: Long? = null, inLibrary: Boolean = true) {
            songs[id] = SongRow(id, title, "art_$artist", artist, liked, likedAt, inLibrary)
        }
        fun play(id: String, hoursAgo: Double, ratio: Double = 1.0, origin: PlayOrigin = PlayOrigin.SEARCH, depth: Int = 0, session: Long = this.session, ended: Int = EndReason.ENDED) {
            val start = now - (hoursAgo * 3_600_000).toLong()
            val dur = 200_000L; val played = (dur * ratio).toLong()
            listens += ListenRow(id, start, start + played, played, dur, ended, origin.code, depth, session, 0)
        }
        fun edge(seed: String, vararg to: String) = to.forEach { edges += Edge(seed, it) }
        fun input(bucket: Int = 0, seen: List<SeenCard> = emptyList(), exclusions: List<ExclusionRow> = emptyList()) =
            EngineInput(now, songs, listens, edges, seen = seen, exclusions = exclusions, bucket = bucket)
    }

    private fun bigWorld(): World {
        val w = World(now)
        // Twenty artists, eight songs each, with a live version of the first song of each artist.
        val artists = 20
        for (a in 0 until artists) for (i in 0 until 8) w.song("a${a}s$i", "artist$a", title = "Song $a $i")
        for (a in 0 until artists) w.song("a${a}live", "artist$a", title = "Song $a 0 (Live)")
        // Everyone is related to the next two artists' songs.
        for (a in 0 until artists) for (i in 0 until 8) for (n in 1..2) w.edge("a${a}s$i", *(0 until 8).map { "a${(a + n) % artists}s$it" }.toTypedArray())
        // A history: the first four songs of artists 0 to 7 played over the last month, artists 8 to 11 long ago, 12 to 19 never.
        var sess = 1L
        for (d in 1..30) { sess++; for (a in 0 until 8) w.play("a${a}s${d % 4}", hoursAgo = d * 24.0 + a, session = sess) }
        for (d in 50..70) { sess++; for (a in 8..11) w.play("a${a}s${d % 8}", hoursAgo = d * 24.0 + a, session = sess) }
        // Yesterday evening: three favourites heard well, for the Again lane.
        w.play("a1s1", hoursAgo = 20.0, session = 998); w.play("a2s2", hoursAgo = 19.5, session = 998); w.play("a3s3", hoursAgo = 19.0, session = 998)
        // Right now: a session with two songs of artist 0.
        w.play("a0s1", hoursAgo = 0.5, session = 999); w.play("a0s2", hoursAgo = 0.2, session = 999)
        return w
    }

    @Test
    fun `an empty library builds nothing and does not crash`() {
        val row = EngineRow.build(EngineInput(now, emptyMap(), emptyList(), emptyList()), random = Random(1))
        assertTrue(row.cards.isEmpty()); assertTrue(row.seeds.isEmpty())
    }

    @Test
    fun `the row keeps every rule`() {
        val w = bigWorld()
        repeat(20) { attempt ->
            val row = EngineRow.build(w.input(), random = Random(attempt.toLong()))
            assertEquals(20, row.cards.size)
            val groups = VersionGroups(w.songs.values)
            // one card per version group
            assertEquals(row.cards.size, row.cards.map { groups.groupOf(it.songId) }.toSet().size)
            // at most two per artist, one per artist per column
            row.cards.groupingBy { w.songs[it.songId]!!.artistId }.eachCount().values.forEach { assertTrue("artist cap", it <= 2) }
            row.cards.chunked(4).forEach { col -> assertEquals(col.size, col.map { w.songs[it.songId]!!.artistId }.toSet().size) }
            // at most three related cards from one seed
            row.cards.filter { it.lane == Lane.RELATED }.groupingBy { it.seedId }.eachCount().values.forEach { assertTrue("seed cap", it <= 3) }
            // no seed and nothing from the current session in the row
            row.cards.forEach { c -> assertTrue("seed in row", c.songId !in row.seeds); assertTrue("just played", c.songId !in setOf("a0s1", "a0s2")) }
            // the first column spans four lanes when every lane has something
            if (row.quotas.values.all { it > 0 } && row.cards.size >= 4) assertEquals(4, row.cards.take(4).map { it.lane }.toSet().size)
            // again cards were heard well between four hours and two weeks ago, never this session
            row.cards.filter { it.lane == Lane.AGAIN }.forEach { c ->
                val lastGood = w.listens.filter { it.songId == c.songId }.maxOf { it.startedAt }
                assertTrue("again too fresh", now - lastGood >= 1 * hour); assertTrue("again too old", now - lastGood <= 14 * day)
            }
            // probabilities are probabilities
            row.cards.forEach { assertTrue(it.p in 0.0..1.0) }
        }
    }

    @Test
    fun `the again lane brings back what was heard well yesterday, not what is playing now`() {
        val w = bigWorld()
        val rows = (0 until 10).map { EngineRow.build(w.input(), random = Random(it.toLong())) }
        assertTrue(rows.any { r -> r.cards.any { it.lane == Lane.AGAIN } })
        rows.forEach { r -> r.cards.forEach { assertTrue(it.songId !in setOf("a0s1", "a0s2")) } }
    }

    @Test
    fun `chips shape the row`() {
        val w = bigWorld()
        // Discover: half the row new.
        val discover = EngineRow.build(w.input().copy(chip = ContextChip.DISCOVER), random = Random(1))
        assertEquals(10, discover.quotas[Lane.EXPLORE])
        // Favourites: nothing new, and seeds only from likes: with no likes there are no seeds at all.
        val favourites = EngineRow.build(w.input().copy(chip = ContextChip.FAVOURITES), random = Random(1))
        assertEquals(0, favourites.quotas[Lane.EXPLORE]); assertTrue(favourites.seeds.isEmpty())
        // A mood with too few tagged listens is Auto; with enough, its seeds come from tagged listens only.
        // Every listen of artist 5 (thirty of them) was made with Focus on.
        val tagged = w.listens.map { l -> if (l.songId.startsWith("a5")) l.copy(contextChip = ContextChip.FOCUS) else l }
        val focus = EngineRow.build(EngineInput(now, w.songs, tagged, w.edges, chip = ContextChip.FOCUS), random = Random(1))
        assertTrue(focus.seeds.isNotEmpty()); focus.seeds.forEach { assertTrue("seed $it not tagged", it.startsWith("a5")) }
        val few = w.listens.mapIndexed { i, l -> if (i < 5) l.copy(contextChip = ContextChip.CHILL) else l }
        val chill = EngineRow.build(EngineInput(now, w.songs, few, w.edges, chip = ContextChip.CHILL), random = Random(1))
        assertTrue(chill.seeds.any { !it.startsWith("a0") || true })   // built as Auto: seeds from everything
        assertTrue(chill.seeds.size > 5)
    }

    @Test
    fun `the dial sets the explore share by largest remainder`() {
        assertEquals(mapOf(Lane.EXPLORE to 2, Lane.RELATED to 7, Lane.AGAIN to 4, Lane.ARTIST to 4, Lane.REDISCOVER to 3), quotas(20, 0.5, false))
        assertEquals(20, quotas(20, 1.0, false).values.sum())
        // Never more than three explore cards, however far the slider goes.
        assertEquals(3, quotas(20, 1.0, false)[Lane.EXPLORE])
        assertEquals(1, quotas(20, 0.0, false)[Lane.EXPLORE])
        assertEquals(20, quotas(20, 0.5, true)[Lane.EXPLORE])
    }

    @Test
    fun `a banned song takes its versions with it and a snoozed artist is gone`() {
        val w = bigWorld()
        val banned = w.input(exclusions = listOf(ExclusionRow(1, "a1s0"), ExclusionRow(2, "art_artist2")))
        repeat(10) { attempt ->
            val row = EngineRow.build(banned, random = Random(attempt.toLong()))
            row.cards.forEach { c ->
                assertTrue(c.songId != "a1s0" && c.songId != "a1live")
                assertTrue(w.songs[c.songId]!!.artistId != "art_artist2")
            }
        }
    }

    @Test
    fun `banning a song does not ban another artist's song of the same name`() {
        // The case that was broken. Kind-1 exclusions were matched by version group, and groups
        // union on equal base titles with the artist deliberately ignored. Titles recur across
        // artists constantly, so "not this song" on one Sunflower hid every other Sunflower, from
        // every lane, for ever, with one entry in the Exclusions screen naming only the first.
        val w = bigWorld()
        // Same title as a1s0, different artist, and reachable: artist 19's songs refer to it.
        w.song("twin", "artist19", title = "Song 1 0")
        w.edge("a19s0", "twin"); w.edge("a19s1", "twin"); w.edge("a19s2", "twin")
        for (d in 1..8) w.play("a19s0", hoursAgo = d * 6.0, session = 2000L + d)

        val banned = w.input(exclusions = listOf(ExclusionRow(1, "a1s0")))
        var twinSeen = false
        repeat(40) { attempt ->
            val row = EngineRow.build(banned, random = Random(attempt.toLong()))
            row.cards.forEach { c ->
                // The ban still holds on the song itself and on its own artist's live version.
                assertTrue("the banned song came back", c.songId != "a1s0")
                assertTrue("the banned song's own version came back", c.songId != "a1live")
                if (c.songId == "twin") twinSeen = true
            }
        }
        assertTrue("another artist's song of the same name is still banned", twinSeen)
    }

    @Test
    fun `explore cards are new to the listener and say so`() {
        val w = bigWorld()
        val row = EngineRow.build(w.input(), random = Random(3))
        val explore = row.cards.filter { it.lane == Lane.EXPLORE }
        assertTrue(explore.isNotEmpty())
        explore.forEach { c ->
            assertTrue(c.features[Features.NOVEL] >= 0.5)
            assertEquals("new_to_you", c.reasons.first())
        }
    }

    @Test
    fun `never played means no listen at all, not no good listen`() {
        val w = bigWorld()
        // Artists 12 to 15 were skipped ten seconds in, every song: new by New songs only's measure,
        // since none was heard well, but not something the listener has never heard.
        val skipped = (12..15).flatMap { a -> (0 until 8).map { "a${a}s$it" } }
        skipped.forEachIndexed { i, id -> w.play(id, hoursAgo = 48.0 + i, ratio = 0.05, session = 500L + i, ended = EndReason.SKIPPED) }
        val heard = w.listens.mapTo(HashSet()) { it.songId }
        val row = EngineRow.build(w.input(), neverPlayed = true, random = Random(5))
        assertTrue("a row to show", row.cards.size >= EngineParams.DEFAULT.minCards)
        (row.cards + row.pool).forEach { assertTrue("${it.songId} has been played", it.songId !in heard) }
        val newOnly = EngineRow.build(w.input(), newOnly = true, random = Random(5))
        assertTrue("New songs only still counts a skip as new", (newOnly.cards + newOnly.pool).any { it.songId in skipped })
    }

    @Test
    fun `never played leaves out what the input bans, such as the cards already in Quick picks`() {
        val w = bigWorld()
        val quickPicks = EngineRow.build(w.input(), neverPlayed = true, random = Random(5)).cards.map { it.songId }.toSet()
        val row = EngineRow.build(w.input().copy(banned = quickPicks), neverPlayed = true, random = Random(5))
        assertTrue(row.cards.none { it.songId in quickPicks })
    }

    @Test
    fun `the same seed gives the same row`() {
        val w = bigWorld()
        val a = EngineRow.build(w.input(), random = Random(7)).cards.map { it.songId }
        val b = EngineRow.build(w.input(), random = Random(7)).cards.map { it.songId }
        assertEquals(a, b)
    }

    @Test
    fun `a session of nothing but skips is still the current session, and its songs stay excluded`() {
        val w = bigWorld()
        // bigWorld's session 999 ended a good listen about nine minutes ago. Under the app's
        // 30-minute session rule, skips this soon after it would join that session rather than
        // open one of their own, so drop it: the last good listen is then session 998, most of a
        // day back, and the skips below make up a session with no good listen in it.
        w.listens.removeAll { it.sessionId == 999L }
        // Right now: the listener skips through four songs of artists 12 to 15 in one session,
        // none heard well, so stats.latestSessionId (which only ever names a session once it has a
        // good, artist-credited listen) cannot see this session and would still point at whatever
        // session last had one, missing this one entirely.
        val skipped = (12..15).map { "a${it}s0" }
        skipped.forEachIndexed { i, id -> w.play(id, hoursAgo = 0.01 * (i + 1), ratio = 0.05, session = 9001L, ended = EndReason.SKIPPED) }
        // The same songs, reachable and counted as novel by newOnly's measure (see "never played
        // means no listen at all, not no good listen" above), so unless this session is taken as
        // the one in progress they are picked up as ordinary candidates.
        repeat(10) { attempt ->
            val row = EngineRow.build(w.input(), newOnly = true, random = Random(attempt.toLong()))
            assertTrue("a row to show", (row.cards + row.pool).isNotEmpty())
            (row.cards + row.pool).forEach { assertTrue("${it.songId} was skipped this session", it.songId !in skipped) }
        }
    }

    @Test
    fun `currentSessionId follows the most recent listen, engagement and artist aside`() {
        val session = { id: String, hoursAgo: Double, sess: Long, ratio: Double, ended: Int ->
            val start = now - (hoursAgo * hour).toLong()
            val played = (200_000 * ratio).toLong()
            ListenRow(id, start, start + played, played, 200_000, ended, PlayOrigin.SEARCH.code, 0, sess, 0)
        }
        // No listens at all.
        assertEquals(-1L, currentSessionId(emptyList()))
        // A single, well-engaged, artist-backed listen: the ordinary case.
        assertEquals(1L, currentSessionId(listOf(session("a", 1.0, 1L, 1.0, EndReason.ENDED))))
        // The most recent listen is a skip in a newer session than an older, good one: it still wins.
        assertEquals(
            2L,
            currentSessionId(listOf(
                session("a", 2.0, 1L, 1.0, EndReason.ENDED),
                session("b", 0.1, 2L, 0.05, EndReason.SKIPPED),
            )),
        )
        // An open row (endedAt already set to now by the loader; startedAt is what is real) still counts.
        assertEquals(
            3L,
            currentSessionId(listOf(
                session("a", 2.0, 1L, 1.0, EndReason.ENDED),
                session("b", 0.05, 3L, 1.0, EndReason.OPEN).copy(endedAt = now),
            )),
        )
    }

    @Test
    fun `a card passed over is demoted and a satiated song seeds weakly`() {
        val w = bigWorld()
        val seen = (1..6).map { SeenCard("a1s3", now - it * day) }
        val plain = EngineRow.build(w.input(), random = Random(11))
        val demoted = EngineRow.build(w.input(seen = seen), random = Random(11))
        val zPlain = (plain.cards + plain.pool).firstOrNull { it.songId == "a1s3" }?.z
        val zDemoted = (demoted.cards + demoted.pool).firstOrNull { it.songId == "a1s3" }?.z
        if (zPlain != null && zDemoted != null) assertTrue(zDemoted < zPlain)
        // Forty full plays of one song in an afternoon: exposure past the ramp.
        val binge = World(now); binge.song("x", "a"); binge.song("y", "a"); binge.edge("x", "y")
        repeat(40) { binge.play("x", hoursAgo = it * 0.1, session = 5) }
        val stats = LibraryStats(binge.input())
        val ctx = Features.Context(stats, VersionGroups(binge.songs.values), binge.input(), emptyMap())
        assertEquals(1.0, Features.of("x", ctx)[Features.SAT], 1e-9)
    }
}
