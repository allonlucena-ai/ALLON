# Building

Building needs JDK 21. From a clone with its submodules (taglib, and ffMetadataEx for the full flavour) to an app:

```bash
git clone --recurse-submodules https://github.com/ItzSkyeYT/InterTune.git
cd InterTune
./gradlew assembleCoreDebug
```

The APK is then in `app/build/outputs/apk/core/debug/`. Android Studio opens the folder as it is and builds the same way.

On a clone made without the submodules, or when a build fails in one of them, fetch them again:

```bash
git submodule update --init --recursive
```

The app runs on Android 7.0 and newer.

## Flavours and build types

| Flavour | What it is |
|---|---|
| `core` | The default, and what every release is |
| `full` | Core plus FFmpeg: a tag reader for local files and more audio decoders. Larger, and it needs [extra setup](https://github.com/OuterTune/ffMetadataEx/blob/main/README.md#building) |

| Build type | Installs as | For |
|---|---|---|
| `debug` | `dev.skye.intertune.debug` | Everyday work, with the features that are still in progress switched on |
| `preview` | `dev.skye.intertune.preview` | The same, installed beside a debug build, to try something on a fresh profile |
| `release` | `dev.skye.intertune` | Releases: shrunk, and signed only where the signing key is |

Debug and preview builds install next to the released app, so they never touch the library in it.

<br/><br/>

# Contributing to InterTune

These guidelines are inherited from OuterTune and still describe how this fork works. Where an
example below links to an OuterTune commit or pull request, it is upstream's, kept because it
illustrates the convention rather than because it happened here.

## Reporting issues

Found something broken? Open an [issue](https://github.com/ItzSkyeYT/InterTune/issues/new/choose) with the bug form, or post in #bug-reports on the [Discord server](https://discord.gg/68jmqhMjXk). In the app, Settings > About > Submit a bug report shows the last thing that went wrong, ready to copy into the report.

Everyone who reports issues is thanked in the [README](https://github.com/ItzSkyeYT/InterTune#people). Thank you!

## Translations

We use Weblate. Thank you for the libre tier.

There are two string files and they are translated in two different places, because only one of
them belongs to this fork.

- `strings-ot.xml` is InterTune's own, and by far the larger of the two. It is translated on
  [our Weblate page](https://hosted.weblate.org/projects/intertune/).
- `strings.xml` comes from OuterTune and is translated on
  [their Weblate page](https://hosted.weblate.org/projects/outertune/). It reaches this repository
  through upstream merges, so translating it here would mean a merge and a sync writing over each
  other every time.

### Important

- Submit translations through Weblate. If something cannot be done there, a pull request is fine
- New strings go in `strings-ot.xml`. Strings ported from upstream go in `strings.xml`
- `values-en-rCA` is not a translation. It is English, and it is what en-GB and en-AU devices read
  **ahead of** `values/`, so any edit to an English string has to touch both files or those
  locales silently keep the old text

## Submitting a pull request

To make everyone's life easier, there are a set of guidelines that are to be followed when submitting pull requests.

- One pull request for one feature/issue, please refrain from tackling many features/issues in one pull request
- Write a descriptive title and a meaningful description
- Upload images/video for any UI changes
- In the event of merge conflicts, you may be required to rebase onto the current default branch
- **You are required to build and test the app before submitting a pull request**

## Using AI tools

AI tools are welcome. You are still the author of what you send, so:

- One task per pull request. A tool makes it easy to change ten things at once: keep them apart.
- Say in the description which tool and model helped, and with what.
- Read every line before you send it. Take out what the change does not need (stray refactors,
  comments that repeat the code, filler in the description) and check that the code is right, not
  only that it compiles.
- Build it and try it on a phone, as with any pull request. One that was never run will be closed.
- The same for issues: describe what you saw yourself. A report a tool wrote about a problem nobody
  saw will be closed.

## Commiting guidelines

- Prefix commits with tags, and provide descriptions if necessary. These are generally done in format:
  `tag: commit_name`. [Example](https://github.com/OuterTune/OuterTune/commit/798e8366227dd2cc38355224c733dbf7e8ffcee0)
    - A list of tags commonly used is provided below
- Commit descriptions are not required, but highly recommended
- When porting/cherry-picking/stealing from other repositories or sources:
    - Maintain
      authorship. [Example](https://github.com/OuterTune/OuterTune/commit/b0dc59682190b41f0200e9df5174322acaa3d40d)
    - If this is not possible please provide the source in the commit
      description. [Example](https://github.com/OuterTune/OuterTune/pull/59/commits/e40325dd86ac2c30347cfd4f9e92bbf15a0d0c82)
- IMPORTANT: When merging the default branch into your branch
    - Best: Please rebase over it
    - Less good: Merging it into your branch via merge commit. We do not like this as it clobbers the commit history.
      If you do this, your pull request will be rebased/squashed and merged
- IMPORTANT: Merge conflicts
    - As per the previous point, please rebase and conflicts are to be resolve in the commits themselves
    - We may ask you to rebase your PR if merge conflicts are an issue when merging
    - In the event you do not wish to rebase, your pull request will be squashed and merged as stated above
- If database schema changes are required, please state clearly if a version increment is required. Additional details
  are in the `Database schema changes` section
- For multi-part commits where all parts are required for functionality, use
  `[1/2], [2/2], etc`. [See example](https://github.com/OuterTune/OuterTune/pull/59/commits)
- Do not mess with translation files directly. `strings-ot.xml` is managed on our Weblate and
  `strings.xml` on upstream's.

### Tags

| Tag (General) | Description                                                                                         |
|---------------|-----------------------------------------------------------------------------------------------------|
| github        | GitHub facing configs, ex. build scripts, templates, etc.                                           |
| gradle        | Dependency/library updates                                                                          |
| readme        | Readme changes                                                                                      |
| fixup         | Amendments to certain commits. this is generally done in the format `fixup: <old commit name here>` |

| Tag (ui) | Description                                                                        |
|----------|------------------------------------------------------------------------------------|
| ui       | User interface                                                                     |
| library  | Library general components. Use the specific ones below if it is a specific change |
| artist   | Playlist screens & components                                                      |
| album    | Album screens & components                                                         |
| playlist | Playlist screens & components                                                      |
| songs    | Song screens & components                                                          |

| Tag (Playback) | Description               |
|----------------|---------------------------|
| player         | Music playback components | 
| multiqueue     | Queue components          |

| Tag (Features) | Description                 |
|----------------|-----------------------------|
| sync           | YouTube Music sync features |
| downloads      | Offline song downloads      |
| innertube      | Innertube module            |

| Tag (Local Media) | Description                      |
|-------------------|----------------------------------|
| lm                | General local library components | 
| scanner           | Local media scanner              |

| Tag (Misc)    | Description                                                                                     |
|---------------|-------------------------------------------------------------------------------------------------|
| `<file name>` | Changes for one single file, that to not fit into any other tags                                |
| app           | General changes, or anything that does not fit any other tags. (For within the app module only) |
| intertune     | General changes that span across multiple modules                                               |
| fastlane      | Fastlane components                                                                             |
| translations  | General changes to translation components                                                       |

- Please use a tag if it already exists, however, if you are developing a new major feature, you are free to assign your
  own appropriate tag
- Tags can be stacked. For example: `ui: library: Something something`

## Database schema changes

- Clearly state if a database version increment is required
- You are require to make sure migration works from the previous database version
- Commits modifying the database version should be all be contained in that single commit
    - These include generating JSON, Entity classes, migration conflict resolution, bumping database version etc.
